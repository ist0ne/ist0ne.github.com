---
layout: post
title: "Saltstack：Salt模块的扩展"
description: "本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。"
category: Saltstack
tags: [saltstack, salt, devops]
---

对Salt进行模块化设计就是为了扩展，另外将变量抽象出来放到pillar中也是为了模块可以重用。当你需要配置两个web平台，而这两个平台又有些许不同时你该怎么办？需要重新再写个nginx模块适配新的平台吗？

对于上面问题的回答是否定的，我们无需再重新写一个nginx模块，我们只需要对新的平台传递新的配置文件或者使用同一个模板传递不同的参数。

#### 使用不同的配置文件

当两个平台配置相差比较大时可能传递一个不同的配置文件会更合适，如下：

    /etc/rsyncd.conf:  
      file.managed:  
        - source: salt://rsync/files/etc/{{salt['pillar.get']('rsync_template', 'rsyncd.conf')}}  
        - template: jinja  
        - user: root  
        - group: root  
        - mode: 644  

为不同的节点在pillar中配置不同的rsync_template变量即可。

#### 使用同一个模板传递不同的参数

    /etc/keepalived/keepalived.conf:  
      file.managed:  
        - source: salt://keepalived/files/etc/keepalived/keepalived.conf  
        - template: jinja  
        - user: root  
        - group: root  
        - mode: 644  

对于主服务器(/srv/salt/pillar/nodes/ha1.sls )使用如下pillar变量：

    keepalived:  
      notification_email: 'dongliang@mall.com'  
      notification_email_from: 'haproxy@mall.com'  
      smtp_server: 127.0.0.1  
      state: MASTER  
      priority: 100  
      auth_type: PASS  
      auth_pass: mall  
      virtual_ipaddress_internal: 172.16.100.100  
      virtual_ipaddress_external: 60.60.60.100  

对于从服务器(/srv/salt/pillar/nodes/ha2.sls )使用如下pillar变量：

    keepalived:  
      notification_email: 'dongliang@mall.com'  
      notification_email_from: 'haproxy@mall.com'  
      smtp_server: 127.0.0.1  
      state: BACKUP  
      priority: 99  
      auth_type: PASS  
      auth_pass: mall  
      virtual_ipaddress_internal: 172.16.100.100  
      virtual_ipaddress_external: 60.60.60.100  

