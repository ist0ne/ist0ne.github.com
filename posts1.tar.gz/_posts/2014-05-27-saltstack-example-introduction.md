---
layout: post
title: "Saltstack：网站架构介绍"
description: "本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。"
category: Saltstack
tags: [saltstack, salt, devops]
---

本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。主要介绍如何使用salt对电商网站各种服务进行管理、基于角色对应用进行自动化监控、基于Saltstack runner的代码部署系统等，主要包括以下主题：

* [网站架构介绍](http://yoyolive.com/saltstack/2014/05/27/saltstack-example-introduction.html)
* [Saltstack安装](http://yoyolive.com/saltstack/2014/05/28/saltstack-install.html)
* [基础服务部署](http://yoyolive.com/saltstack/2014/05/29/saltstack-base-service.html)
* [服务部署](http://yoyolive.com/saltstack/2014/06/14/saltstack-service.html)
* [代码部署系统搭建](http://yoyolive.com/saltstack/2014/06/15/saltstack-publish.html)
* [自动化监控](http://yoyolive.com/saltstack/2014/06/16/saltstack-zabbix-monitor.html)
* [Salt模块的扩展](http://yoyolive.com/saltstack/2014/06/17/saltstack-expand.html)

项目代码已放到GitHub上，地址：https://github.com/ist0ne/salt-states

## 网站架构介绍

### 网络架构

1.  使用Haproxy做负载均衡，一主一备，当主服务器宕机后备服务器自动接替主服务器角色对外提供服务。
2.  WEB前端采用Nginx+PHP提供动态页面的访问；所有前端服务器通过NFS协议挂载共享存储，商品展示图片上传至存储中，图片访问时通过Varnish进行缓存加速。
3.  使用memcached做缓冲层来提高访问速度和减轻数据库的压力；使用Redis做队列服务。
4.  数据持久层使用MySQL，MySQL采用主从模式，通过主从分离提高访问速度。
5.  使用Salt对整个系统进行配置管理；使用Zabbix进行系统监控；所有服务器通过跳板机进行登录。
6.  使用SVN统一管理代码和配置信息。

![网络架构](http://yoyolive.com/assets/images/14-05-27/net.png)
说明:上面网络架构未按实际服务器数量画出，具体服务器见角色划分部分。

### 系统架构

1.  统一管理：整个系统通过Salt进行配置管理，所有配置文件统一存储到SVN中，通过SVN版本控制能够在系统故障时轻松回退到上一个正常版本。
2.  代码部署：通过命令行部署工具从SVN中检出代码并部署到WEB前端，做到简单轻松部署。
3.  应用架构：采用经典的三层架构--代码解析层、缓冲层、数据持久化层。缓冲层对用户数据进行缓存，不必每次都去数据库提取数据，减轻数据库压力；数据库采用主从架构，读写分离，减轻主库负载，提高了用户的访问速度。
4.  动静态分离：图片、CSS、JS与动态程序分离，通过Varnish进行加速，提升用户体验。
5.  Zabbix监控：基于角色的自动监控机制，通过Zabbix对系统状态、应用状态进行自动监控。

![系统架构](http://yoyolive.com/assets/images/14-05-27/sys.png)

### 角色划分（主机名、IP地址分配）

说明：所有服务器配置内、外双网卡，eth0为内网，eth1为外网。操作系统统一部署CentOS 6.5 64位。

#### 负载均衡（ha）

需要两台服务器作为负载均衡器使用，两台服务器配置为主备模式，当主服务器宕机后从服务器自动接管服务。

* ha1.grid.mall.com 60.60.60.11 172.16.100.11
* ha2.grid.mall.com 60.60.60.12 172.16.100.12

#### Web前端（web）

需要三台服务器作为Web前端服务器，对外提供Web服务，Web服务通过负载均衡供用户访问。

* web1.grid.mall.com 60.60.60.21 172.16.100.21
* web2.grid.mall.com 60.60.60.22 172.16.100.22
* web3.grid.mall.com 60.60.60.23 172.16.100.23

#### 图片缓存（cache）

需要两台服务器作为商品图片的缓存服务器，缓存服务器通过负载均衡供用户访问。

* cache1.grid.mall.com 60.60.60.31 172.16.100.31
* cache2.grid.mall.com 60.60.60.32 172.16.100.32

#### 缓存服务和队列服务（mc）

需要两台服务器提供缓冲服务器和队列服务。

* mc1.grid.mall.com 60.60.60.41 172.16.100.41
* mc2.grid.mall.com 60.60.60.42 172.16.100.42

#### 数据库（db）

需要两台服务器提供数据库服务，两台服务器通过主从复制同步数据。

* db1.grid.mall.com 60.60.60.51 172.16.100.51
* db2.grid.mall.com 60.60.60.52 172.16.100.52

#### 搜索（search）

需要两台服务器提供搜索服务。

* search1.grid.mall.com 60.60.60.61 172.16.100.61
* search2.grid.mall.com 60.60.60.62 172.16.100.62

#### 共享存储（storage）

需要一台服务器提供存储服务。

* storage1.grid.mall.com 60.60.60.71 172.16.100.71

#### 管理机（admin）

需要一台管理机，上面部署Salt master，zabbix，svn等管理服务。

* admin.grid.mall.com 60.60.60.81 172.16.100.81


