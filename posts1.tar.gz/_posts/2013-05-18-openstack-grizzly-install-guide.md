---
layout: post
title: "OpenStack Grizzly 安装指南"
description: "你想安装OpenStack Grizzly但是不知道如何开始，你可以看看本指南！他容易、简单且经过了测试。还等什么？试试吧!"
category: 虚拟化
tags: [OpenStack]
---


你想安装OpenStack Grizzly但是不知道如何开始，你可以看看本指南！

他容易、简单且经过了测试。还等什么？试试吧: 


[OpenStack Grizzly安装指南](https://github.com/ist0ne/OpenStack-Grizzly-Install-Guide-CN/blob/master/OpenStack_Grizzly_Install_Guide.rst)（Quantum plugin采用Linux Bridge，单节点）

[OpenStack Grizzly安装指南](https://github.com/ist0ne/OpenStack-Grizzly-Install-Guide-CN/blob/OVS_SingleNode/OpenStack_Grizzly_Install_Guide.rst)
（Quantum plugin采用OpenVSwitch，单节点）

[OpenStack Grizzly安装指南](https://github.com/ist0ne/OpenStack-Grizzly-Install-Guide-CN/blob/OVS_MutliNode/OpenStack_Grizzly_Install_Guide.rst)（Quantum plugin采用OpenVSwitch，多节点，控制节点+网络节点+计算节点）

[OpenStack Grizzly安装指南](https://github.com/ist0ne/OpenStack-Grizzly-Install-Guide-CN/blob/OVS_Quantum_MutliNode/OpenStack_Grizzly_Install_Guide.rst)（Quantum plugin采用OpenVSwitch，多节点，控制节点+计算、网络节点）

