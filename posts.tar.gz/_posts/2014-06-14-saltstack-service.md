---
layout: post
title: "Saltstack：服务部署"
description: "本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。"
category: Saltstack
tags: [saltstack, salt, devops]
---

本文以web服务器为例介绍salt服务的部署。把不同的服务组织成不同的角色，然后将角色应用到不同的节点上。通过角色的划分能够清晰的对不同的服务模块进行组织，所有角色的配置放到/srv/salt/roles下，角色用到的相关变量放到/srv/pillar/roles和/srv/pillar/nodes下，其中/srv/pillar/nodes下放置与具体节点相关的变量。

### 角色与配置文件

/srv/salt/roles/web.sls配置如下，包括nginx模块、rsync模块、limits模块和nfs.client：

    include:  
      - nginx  
      - rsync  
      - limits 
      - nfs.client  

变量/srv/pillar/roles/web.sls如下，没有单独应用到节点的变量:

    hostgroup: web  # 定义zabbix分组，具体见后文的自动化监控一节  
    vhostsdir: /data1/vhosts  # 代码发布目录  
    vhostscachedir: /data1/cache  # 程序临时目录  
    logdir: /data1/logs  # nginx日志目录  
    vhosts:  # 虚拟主机名，用于创建对用的代码发布目录  
      - www.mall.com  
      - static.mall.com  
    limit_users:  # 对用户打开文件数做设置  
      nginx:  
        limit_hard: 65535  
        limit_soft: 65535  
        limit_type: nofile  
    mounts: # nfs共享存储挂载相关配置  
      /data1/vhosts/static.mall.com/htdocs:  
        device: 172.16.100.71:/data1/share  
        fstype: nfs  
        mkmnt: True  
        opts: async,noatime,noexec,nosuid,soft,timeo=3,retrans=3,intr,retry=3,rsize=16384,wsize=16384  

### Nginx+PHP配置

管理模块：/srv/salt/nginx/  
nginx配置文件：/srv/salt/nginx/files/etc/nginx/，其中包括主配置文件、虚拟主机配置文件、和环境变量配置文件。  
php配置文件：主配置文件：/srv/salt/nginx/files/etc/php.ini 模块配置文件：/srv/salt/nginx/files/etc/php.d/  
php-fpm配置文件：主配置文件：/srv/salt/nginx/files/etc/php-fpm.conf 其他配置文件：/srv/salt/nginx/files/etc/php-fpm.d/  
角色配置：/srv/pillar/roles/web.sls  

#### 详细说明

/srv/salt/nginx/init.sls用于组织整个nginx模块：
 
    include:
      - nginx.server  # 包含nginx相关配置
      - nginx.php  # 包含php相关配置
      - nginx.monitor # 包含监控相关配置

/srv/salt/nginx/server.sls用于配置nginx服务：

定义nginx相关配置，主要包括安装nginx软件包配置相关配置文件，并启动nginx服务。  
![nginx server 1](/assets/images/14-06-14/nginx_server_1.png)

创建日志目录、代码发布目录、代码缓存目录。并配置服务角色，角色也用于对服务的监控，详见后文自动化监控。  
![nginx server 2](/assets/images/14-06-14/nginx_server_2.png)


/srv/salt/nginx/php.sls用于配置php服务：

定义php相关配置，主要包括安装php软件包配置相关配置文件，启动php-fpm服务，并配置服务角色。

    php-fpm:  
      pkg:  
        - name: php-fpm  
        - pkgs:  
          - php-fpm  
          - php-common  
          - php-cli  
          - php-devel  
          - php-pecl-memcache  
          - php-pecl-memcached  
          - php-gd  
          - php-pear  
          - php-mbstring  
          - php-mysql  
          - php-xml  
          - php-bcmath  
          - php-pdo  
        - installed  
      service:  
        - running  
        - require:  
          - pkg: php-fpm  
        - watch:  
          - pkg: php-fpm  
          - file: /etc/php.ini  
          - file: /etc/php.d/  
          - file: /etc/php-fpm.conf  
          - file: /etc/php-fpm.d/  
  
    /etc/php.ini:  
      file.managed:  
        - source: salt://nginx/files/etc/php.ini  
        - user: root  
        - group: root  
        - mode: 644  
  
    /etc/php.d/:  
      file.recurse:  
        - source: salt://nginx/files/etc/php.d/  
        - user: root  
        - group: root  
        - dir_mode: 755  
        - file_mode: 644  
  
    /etc/php-fpm.conf:  
      file.managed:  
        - source: salt://nginx/files/etc/php-fpm.conf  
        - user: root  
        - group: root  
        - mode: 644  
  
    /etc/php-fpm.d/:  
      file.recurse:  
        - source: salt://nginx/files/etc/php-fpm.d/  
        - user: root  
        - group: root  
        - dir_mode: 755  
        - file_mode: 644  
  
    php-fpm-role:  # 定义php-fpm角色  
      file.append:  
        - name: /etc/salt/roles  
        - text:  
          - 'php-fpm'  
        - require:  
          - file: roles  
          - service: php-fpm  
          - service: salt-minion  
        - watch_in:  
          - module: sync_grains  

/srv/salt/nginx/monitor.sls用于配置对服务的监控：

    include:  
      - zabbix.agent  
      - nginx  
  
    nginx-monitor:  
      pkg.installed:  # 安装脚本依赖的软件包  
        - name: perl-libwww-perl  
  
    php-fpm-monitor-script:  # 管理监控脚本，如果脚本存放目录不存在自动创建  
      file.managed:  
        - name: /etc/zabbix/ExternalScripts/php-fpm_status.pl  
        - source: salt://nginx/files/etc/zabbix/ExternalScripts/php-fpm_status.pl  
        - user: root  
        - group: root  
        - mode: 755  
        - require:  
          - service: php-fpm  
          - pkg: nginx-monitor  
          - cmd: php-fpm-monitor-script  
      cmd.run:  
        - name: mkdir -p /etc/zabbix/ExternalScripts  
        - unless: test -d /etc/zabbix/ExternalScripts  
  
    php-fpm-monitor-config:  # 定义zabbix客户端用户配置文件  
      file.managed:  
        - name: /etc/zabbix/zabbix_agentd.conf.d/php_fpm.conf  
        - source: salt://nginx/files/etc/zabbix/zabbix_agentd.conf.d/php_fpm.conf  
        - require:  
          - file: php-fpm-monitor-script  
          - service: php-fpm  
        - watch_in:  
          - service: zabbix-agent  
  
    nginx-monitor-config:  # 定义zabbix客户端用户配置文件  
      file.managed:  
        - name: /etc/zabbix/zabbix_agentd.conf.d/nginx.conf  
        - source: salt://nginx/files/etc/zabbix/zabbix_agentd.conf.d/nginx.conf  
        - template: jinja  
        - require:  
          - service: nginx  
        - watch_in:  
          - service: zabbix-agent  

其他角色的部署跟web相似，不一一列出。
