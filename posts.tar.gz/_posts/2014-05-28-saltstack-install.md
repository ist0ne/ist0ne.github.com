---
layout: post
title: "Saltstack：安装"
description: "本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。"
category: Saltstack
tags: [saltstack, salt, devops]
---

本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。本节主要讲述Saltstack的安装过程。

## Saltstack安装

Saltstack源码地址：https://github.com/saltstack/salt，最新版本为v2014.1.4。
需要自己[打rpm包](http://yoyolive.com/%E5%85%B6%E4%BB%96/2014/05/22/rpm-pkg.html)，salt描述文件：https://github.com/saltstack/salt/blob/develop/pkg/rpm/salt.spec，另外最新版本的salt需要python-libcloud，也需要提前打好包。如果是在CentOS 5.x 上安装salt，需要升级zeromq到3.x版。将所有打好的rpm包放入yum仓库，开始安装。

### Salt Master安装

注意：安装前确保主机名已按角色划分部分进行配置。

安装salt-master：

>\# yum install -y salt-master

修改配置文件：/etc/salt/master，使salt监听在内网网卡上。

>interface: 172.16.100.81

启动Salt Master：

>\# /etc/init.d/salt-master start

查看启动情况，4505端口处于监听状态：

>\# netstat -tunlp |grep 4505

### Salt Minion安装

注意：安装前确保主机名已按角色划分部分进行配置。

安装salt-minion：

>\# yum install -y salt-minion

修改配置文件：/etc/salt/minion，使其连接到master。

>master: 172.16.100.81

启动Salt Minion：

>\# /etc/init.d/salt-minion start

查看启动情况，4506端口处于监听状态：

>\# netstat -tunlp |grep 4506

### 在Salt Master上为Salt Minion授权

查看Salt Minion是否已经向Salt Master请求授权：

>\# salt-key -L  
Accepted Keys:  
Unaccepted Keys:  
admin.grid.mall.com  


为Salt Minion授权：

>\# salt-key -a admin.grid.mall.com

