---
layout: post
title: "Openstack 使用"
description: "Openstack 使用"
category: 虚拟化
tags: [Openstack, KVM, Ceph, CoreOS]
---

OpenStack作为基础设施即服务（简称IaaS）资源的通用前端。首要任务是简化云的部署过程并为其带来良好的可扩展性。本文希望通过提供必要的指导信息，帮助大家利用OpenStack前端来设置及管理自己的私有云。

导入虚拟机镜像
-------------

如下列出了一下虚拟机镜像，可以在本地下载后通过Openstack界面导入。

https://openstack.redhat.com/Image_resources

也可以参考如下文档自己制作镜像：

https://www.ibm.com/developerworks/community/wikis/home?lang=en#!/wiki/OpenStack/page/Creating%20qcow2%20CentOS%20Image%20for%20OpenStack

导入镜像：

点击左侧的镜像 选项卡，可以看到已经导入的镜像，点击创建镜像 按钮创建镜像。

![Openstack镜像](/assets/images/14-09-10/openstack_images.png)

填写 镜像名称，镜像源选择—镜像文件，格式选择 QCOW2，勾选 公有 框（这样你上传得镜像其他人也能使用），然后点击创建镜像。

![Openstack创建镜像](/assets/images/14-09-10/openstack_create_image.png)

创建虚拟机
---------

点击左侧的 实例 选项卡，可以看到已创建的虚拟机，点击右上角的启动云主机创建 虚拟机。

![Openstack创建虚拟机1](/assets/images/14-09-10/openstack_create_vm_1.png)

在详情选项卡填写云主机名称、选择云主机的规格类型、云主机数量、云主机启动的源，本文从镜像启动，然后选择镜像名称，点击 访问 & 安全选项卡。

![Openstack创建虚拟机2](/assets/images/14-09-10/openstack_create_vm_2.png)

选择一个秘钥对，如果没有需要点击加按钮进行创建，此秘钥对用于登陆创建的虚拟主机（在Openstack中虚拟主机的登陆一般不是通过用户名密码登陆的）。安全组选择default（用于设置防火墙规则）。

![Openstack创建虚拟机3](/assets/images/14-09-10/openstack_create_vm_3.png)

如下创建秘钥对：

![Openstack创建虚拟机4](/assets/images/14-09-10/openstack_create_vm_4.png)

点击 网络 选项卡，点击网络框中的+为虚拟机选择私有网络。

![Openstack创建虚拟机5](/assets/images/14-09-10/openstack_create_vm_5.png)

以上设置完成后点击运行，开始创建虚拟机。

![Openstack创建虚拟机6](/assets/images/14-09-10/openstack_create_vm_6.png)

点击更多，分配浮动IP地址，虚拟机只能通过浮动IP地址进行登陆。

![Openstack创建虚拟机7](/assets/images/14-09-10/openstack_create_vm_7.png)

访问 & 安全
----------

默认情况下，创建的虚拟机不能被ping 通和进行ssh 连接，需要修改默认安全规则。点击 管理规则。

![Openstack访问 & 安全1](/assets/images/14-09-10/openstack_access_1.png)

然后点击添加规则。

![Openstack访问 & 安全2](/assets/images/14-09-10/openstack_access_2.png)

如下添加ICMP规则，允许虚拟机被ping通。

![Openstack访问 & 安全3](/assets/images/14-09-10/openstack_access_3_icmp.png)

添加SSH规则，允许虚拟机通过SSH客户端进行连接。

![Openstack访问 & 安全4](/assets/images/14-09-10/openstack_access_4_ssh.png)

分配完浮动IP地址并设置好安全规则就可以登陆虚拟机了（必须在生成ssh key的机器上进行登陆）。

    [root@fuel ~]# ssh centos@172.16.200.133
    [centos@vm-centos-7 ~]$ sudo su -
    [root@vm-centos-7 ~]#

为虚拟机挂载数据盘
----------------

点击 左侧的 云硬盘 选项卡，点击 创建云硬盘 按钮，然后如下填写 创建云硬盘。

![Openstack云硬盘1](/assets/images/14-09-10/openstack_vdisk_1.png)

然后点击更多，选择 编辑挂载。

![Openstack云硬盘2](/assets/images/14-09-10/openstack_vdisk_2.png)

选择要连接到的虚拟机，然后连接数据盘。

![Openstack云硬盘3](/assets/images/14-09-10/openstack_vdisk_3.png)

登陆虚拟机，对已挂在的数据盘进行分区。

![Openstack云硬盘4](/assets/images/14-09-10/openstack_vdisk_4.png)

![Openstack云硬盘5](/assets/images/14-09-10/openstack_vdisk_5.png)

格式化数据盘并挂载。

![Openstack云硬盘6](/assets/images/14-09-10/openstack_vdisk_6.png)

将需要挂载的数据盘 写入/etc/fstab文件，以便开机自动挂载。

![Openstack云硬盘7](/assets/images/14-09-10/openstack_vdisk_7.png)

为admin租户新增网段
-----------------

\# 设置认证信息

[root@node-9 ~]# cat creds-admin

    export OS_TENANT_NAME=admin
    export OS_USERNAME=admin
    export OS_PASSWORD=admin
    export OS_AUTH_URL="http://172.16.200.2:5000/v2.0/“

\# 使认证信息生效

[root@node-9 ~]# . creds-admin

\# 列出所有租户信息，admin的租户ID为：f51b22163f504dd6a6014f4700e9ee48

[root@node-9 ~]# keystone tenant-list

    +----------------------------------+----------+---------+
    |                id                |   name   | enabled |
    +----------------------------------+----------+---------+
    | f51b22163f504dd6a6014f4700e9ee48 |  admin   |   True  |
    | 8dc964cb23414e1497a74db79ddb563f | services |   True  |
    +----------------------------------+----------+---------+

\# 为admin租户添加网络net_admin，net_admin网络ID为：284d3f00-042b-41b2-bec4-f5bc7dcee037

[root@node-9 ~]# neutron net-create --tenant-id f51b22163f504dd6a6014f4700e9ee48 net_admin

    Created a new network:
    +---------------------------+--------------------------------------+
    | Field                     | Value                                |
    +---------------------------+--------------------------------------+
    | admin_state_up            | True                                 |
    | id                        | 284d3f00-042b-41b2-bec4-f5bc7dcee037 |
    | name                      | net_admin                            |
    | provider:network_type     | vlan                                 |
    | provider:physical_network | physnet2                             |
    | provider:segmentation_id  | 511                                  |
    | shared                    | False                                |
    | status                    | ACTIVE                               |
    | subnets                   |                                      |
    | tenant_id                 | f51b22163f504dd6a6014f4700e9ee48     |
    +---------------------------+--------------------------------------+

\# 为net_admin网络添加子网，子网ID：31896641-28e4-4983-b24d-f37348286a85

[root@node-9 ~]# neutron subnet-create --name net_admin__subnet --tenant-id f51b22163f504dd6a6014f4700e9ee48 net_admin 192.168.101.0/24

    Created a new subnet:
    +------------------+------------------------------------------------------+
    | Field            | Value                                                |
    +------------------+------------------------------------------------------+
    | allocation_pools | {"start": "192.168.101.2", "end": "192.168.101.254"} |
    | cidr             | 192.168.101.0/24                                     |
    | dns_nameservers  |                                                      |
    | enable_dhcp      | True                                                 |
    | gateway_ip       | 192.168.101.1                                        |
    | host_routes      |                                                      |
    | id               | 31896641-28e4-4983-b24d-f37348286a85                 |
    | ip_version       | 4                                                    |
    | name             | net_admin__subnet                                    |
    | network_id       | 284d3f00-042b-41b2-bec4-f5bc7dcee037                 |
    | tenant_id        | f51b22163f504dd6a6014f4700e9ee48                     |
    +------------------+------------------------------------------------------+

\# 修改子网dns地址
[root@node-9 ~]# neutron subnet-update 31896641-28e4-4983-b24d-f37348286a85 --dns_nameservers list=true 8.8.4.4 8.8.8.8
Updated subnet: 31896641-28e4-4983-b24d-f37348286a85

\# 列出路由器信息，路由器ID为：dfcf3d90-2409-4505-a020-58b8ed3c9e67

[root@node-9 ~]# neutron router-list

    +--------------------------------------+----------+-----------------------------------------------------------------------------+
    | id                                   | name     | external_gateway_info                                                       |
    +--------------------------------------+----------+-----------------------------------------------------------------------------+
    | dfcf3d90-2409-4505-a020-58b8ed3c9e67 | router04 | {"network_id": "c4448c0d-f633-449a-861a-a39a304cad21", "enable_snat": true} |
    +--------------------------------------+----------+-----------------------------------------------------------------------------+

\# 将子网（31896641-28e4-4983-b24d-f37348286a85）连接到路由器（dfcf3d90-2409-4505-a020-58b8ed3c9e67）上

[root@node-9 ~]# neutron router-interface-add dfcf3d90-2409-4505-a020-58b8ed3c9e67 31896641-28e4-4983-b24d-f37348286a85

    Added interface a8e6c89f-45a4-4b20-876c-844e46f09a46 to router dfcf3d90-2409-4505-a020-58b8ed3c9e67.

\# 列出代理信息，DHCP代理ID为：75a25941-0b13-4efc-aea8-ad7150d3e89e

[root@node-9 ~]# neutron agent-list

    +--------------------------------------+--------------------+------------------+-------+----------------+
    | id                                   | agent_type         | host             | alive | admin_state_up |
    +--------------------------------------+--------------------+------------------+-------+----------------+
    | 1544e83b-a495-4a46-b43c-b050596ecc9a | Open vSwitch agent | node-11.leju.com | :-)   | True           |
    | 2117339e-039d-4eb7-b7f0-6e645c50c69d | Metadata agent     | node-9.leju.com  | :-)   | True           |
    | 75a25941-0b13-4efc-aea8-ad7150d3e89e | DHCP agent         | node-9.leju.com  | :-)   | True           |
    | c8701380-1705-436f-858d-2b79a17dcff8 | L3 agent           | node-9.leju.com  | :-)   | True           |
    | fa010ebe-db3b-4251-9c89-59c864d54971 | Open vSwitch agent | node-9.leju.com  | :-)   | True           |
    +--------------------------------------+--------------------+------------------+-------+----------------+

\# 为net_admin网络添加DHCP代理，以便此网段能够自动分配IP地址

[root@node-9 ~]# neutron dhcp-agent-network-add 75a25941-0b13-4efc-aea8-ad7150d3e89e net_admin

    Added network net_admin to DHCP agent

\# 完成后网络拓扑如图所示(net_admin和net04都是是通过router04与net04_ext相连的，Openstack控制界面上显示异常)：

![Openstack网络拓扑](/assets/images/14-09-10/openstack_tuopu.png)

添加租户并设置网络
----------------

添加租户op.leju.com，并为租户添加网络：

\# 使认证信息生效

[root@node-9 ~]# . creds-admin

\# 创建op.leju.com租户，租户ID为：2e8def45720343fb9d648bd561a99c06

[root@node-9 ~]# keystone tenant-create --name op.leju.com

    +-------------+----------------------------------+
    |   Property  |              Value               |
    +-------------+----------------------------------+
    | description |                                  |
    |   enabled   |               True               |
    |      id     | 2e8def45720343fb9d648bd561a99c06 |
    |     name    |           op.leju.com            |
    +-------------+----------------------------------+

\# 为租户创建用户

[root@node-9 ~]# keystone user-create --name=dongliang --pass=123456 --tenant-id=2e8def45720343fb9d648bd561a99c06 --email=dongliang@leju.com

    +----------+----------------------------------+
    | Property |              Value               |
    +----------+----------------------------------+
    |  email   |        dongliang@leju.com        |
    | enabled  |               True               |
    |    id    | 181390a3b29d4e3fa9938aa7d65bb0b3 |
    |   name   |            dongliang             |
    | tenantId | 2e8def45720343fb9d648bd561a99c06 |
    | username |            dongliang             |
    +----------+----------------------------------+

\# 列出角色信息

[root@node-9 ~]# keystone role-list

    +----------------------------------+-----------------+
    |                id                |       name      |
    +----------------------------------+-----------------+
    | d6284307ed704c9da4ab426f123e3c9f |      Member     |
    | 9fe2ff9ee4384b1894a90878d3e92bab |     _member_    |
    | f44b81985a3849f1ae98e36357cdad0d |      admin      |
    | e45948cda56f4306b17cb408c7d33b9b | heat_stack_user |
    +----------------------------------+-----------------+

\# 为dongliang用户添加角色

[root@node-9 ~]# keystone user-role-add --tenant-id 2e8def45720343fb9d648bd561a99c06 --user-id 181390a3b29d4e3fa9938aa7d65bb0b3 --role-id d6284307ed704c9da4ab426f123e3c9f

\# 为op.leju.com 租户添加网络 net_op_leju_com，具体参见为admin租户新增网段

[root@node-9 ~]# neutron net-create --tenant-id 2e8def45720343fb9d648bd561a99c06 net_op_leju_com

    Created a new network:
    +---------------------------+--------------------------------------+
    | Field                     | Value                                |
    +---------------------------+--------------------------------------+
    | admin_state_up            | True                                 |
    | id                        | 429f5040-ca24-42ff-9260-a5148ff47391 |
    | name                      | net_op_leju_com                      |
    | provider:network_type     | vlan                                 |
    | provider:physical_network | physnet2                             |
    | provider:segmentation_id  | 512                                  |
    | shared                    | False                                |
    | status                    | ACTIVE                               |
    | subnets                   |                                      |
    | tenant_id                 | 2e8def45720343fb9d648bd561a99c06     |
    +---------------------------+--------------------------------------+

[root@node-9 ~]# neutron subnet-create --tenant-id 2e8def45720343fb9d648bd561a99c06 net_op_leju_com 172.16.102.0/24

    Created a new subnet:
    +------------------+----------------------------------------------------+
    | Field            | Value                                              |
    +------------------+----------------------------------------------------+
    | allocation_pools | {"start": "172.16.102.2", "end": "172.16.102.254"} |
    | cidr             | 172.16.102.0/24                                    |
    | dns_nameservers  |                                                    |
    | enable_dhcp      | True                                               |
    | gateway_ip       | 172.16.102.1                                       |
    | host_routes      |                                                    |
    | id               | e13718ef-58a0-4741-9fed-963f393202c1               |
    | ip_version       | 4                                                  |
    | name             |                                                    |
    | network_id       | 429f5040-ca24-42ff-9260-a5148ff47391               |
    | tenant_id        | 2e8def45720343fb9d648bd561a99c06                   |
    +------------------+----------------------------------------------------+

\# 修改子网dns地址
[root@node-9 ~]# neutron subnet-update e13718ef-58a0-4741-9fed-963f393202c1 --dns_nameservers list=true 8.8.4.4 8.8.8.8
Updated subnet: e13718ef-58a0-4741-9fed-963f393202c1

[root@node-9 ~]# neutron router-list

    +--------------------------------------+----------+-----------------------------------------------------------------------------+
    | id                                   | name     | external_gateway_info                                                       |
    +--------------------------------------+----------+-----------------------------------------------------------------------------+
    | dfcf3d90-2409-4505-a020-58b8ed3c9e67 | router04 | {"network_id": "c4448c0d-f633-449a-861a-a39a304cad21", "enable_snat": true} |
    +--------------------------------------+----------+-----------------------------------------------------------------------------+

[root@node-9 ~]# neutron router-interface-add dfcf3d90-2409-4505-a020-58b8ed3c9e67 e13718ef-58a0-4741-9fed-963f393202c1

    Added interface 4d978e71-1b97-46d3-9f6a-7ace3aa54b3d to router dfcf3d90-2409-4505-a020-58b8ed3c9e67.

[root@node-9 ~]# neutron agent-list

    +--------------------------------------+--------------------+------------------+-------+----------------+
    | id                                   | agent_type         | host             | alive | admin_state_up |
    +--------------------------------------+--------------------+------------------+-------+----------------+
    | 1544e83b-a495-4a46-b43c-b050596ecc9a | Open vSwitch agent | node-11.leju.com | :-)   | True           |
    | 2117339e-039d-4eb7-b7f0-6e645c50c69d | Metadata agent     | node-9.leju.com  | :-)   | True           |
    | 75a25941-0b13-4efc-aea8-ad7150d3e89e | DHCP agent         | node-9.leju.com  | :-)   | True           |
    | c8701380-1705-436f-858d-2b79a17dcff8 | L3 agent           | node-9.leju.com  | :-)   | True           |
    | fa010ebe-db3b-4251-9c89-59c864d54971 | Open vSwitch agent | node-9.leju.com  | :-)   | True           |
    +--------------------------------------+--------------------+------------------+-------+----------------+

[root@node-9 ~]# neutron dhcp-agent-network-add 75a25941-0b13-4efc-aea8-ad7150d3e89e net_op_leju_com

    Added network net_op_leju_com to DHCP agent

[root@node-9 ~]# neutron net-list

    +--------------------------------------+-----------------+-------------------------------------------------------+
    | id                                   | name            | subnets                                               |
    +--------------------------------------+-----------------+-------------------------------------------------------+
    | 284d3f00-042b-41b2-bec4-f5bc7dcee037 | net_admin       | 31896641-28e4-4983-b24d-f37348286a85 192.168.101.0/24 |
    | 35030315-0abb-4321-bd2d-fa02ecebe4a4 | net04           | 33fec45a-5a55-4e66-b5d0-d243a63b5b52 192.168.100.0/24 |
    | 429f5040-ca24-42ff-9260-a5148ff47391 | net_op_leju_com | e13718ef-58a0-4741-9fed-963f393202c1 172.16.102.0/24  |
    | c4448c0d-f633-449a-861a-a39a304cad21 | net04_ext       | fc9caac9-d9a9-43f4-9fec-feebc14038cd 172.16.200.0/24  |
    +--------------------------------------+-----------------+-------------------------------------------------------+

[root@node-9 ~]# neutron net-show c4448c0d-f633-449a-861a-a39a304cad21

    +---------------------------+--------------------------------------+
    | Field                     | Value                                |
    +---------------------------+--------------------------------------+
    | admin_state_up            | True                                 |
    | id                        | c4448c0d-f633-449a-861a-a39a304cad21 |
    | name                      | net04_ext                            |
    | provider:network_type     | flat                                 |
    | provider:physical_network | physnet1                             |
    | provider:segmentation_id  |                                      |
    | router:external           | True                                 |
    | shared                    | *False*                              |
    | status                    | ACTIVE                               |
    | subnets                   | fc9caac9-d9a9-43f4-9fec-feebc14038cd |
    | tenant_id                 | f51b22163f504dd6a6014f4700e9ee48     |
    +---------------------------+--------------------------------------+

\# 修改net04_ext网络为共享模式

[root@node-9 ~]# neutron net-update c4448c0d-f633-449a-861a-a39a304cad21 --shared

    Updated network: c4448c0d-f633-449a-861a-a39a304cad21

[root@node-9 ~]# neutron net-show c4448c0d-f633-449a-861a-a39a304cad21

    +---------------------------+--------------------------------------+
    | Field                     | Value                                |
    +---------------------------+--------------------------------------+
    | admin_state_up            | True                                 |
    | id                        | c4448c0d-f633-449a-861a-a39a304cad21 |
    | name                      | net04_ext                            |
    | provider:network_type     | flat                                 |
    | provider:physical_network | physnet1                             |
    | provider:segmentation_id  |                                      |
    | router:external           | True                                 |
    | shared                    | *True*                               |
    | status                    | ACTIVE                               |
    | subnets                   | fc9caac9-d9a9-43f4-9fec-feebc14038cd |
    | tenant_id                 | f51b22163f504dd6a6014f4700e9ee48     |
    +---------------------------+--------------------------------------+

\# 完成后网络拓扑如图所示(net_op_leju_com是通过router04与net04_ext相连的，Openstack控制界面上显示异常)：


注意： 以上租户和网络创建都是通过命令行添加的，Openstack界面也可以实现部分功能，但有时添加会有问题，建议使用命令行添加。

\# 如需要修改网络端口IP，可以如下修改：

root@node-15:~# neutron port-list

    +--------------------------------------+------+-------------------+--------------------------------------------------------------------------------------+
    | id                                   | name | mac_address       | fixed_ips                                                                            |
    +--------------------------------------+------+-------------------+--------------------------------------------------------------------------------------+
    | 03ecb6fc-a695-4151-aef8-87a64c863be3 |      | fa:16:3e:0c:e0:60 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.132"}  |
    | 194d33d5-5184-41cb-9a30-09e580bc4d3f |      | fa:16:3e:1a:20:66 | {"subnet_id": "5dd3709e-3171-40a5-891c-bc2d73c0a9a0", "ip_address": "192.168.111.3"} |
    | 29c50618-af2d-401b-bfe3-3ef38d2292c4 |      | fa:16:3e:71:c4:d0 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.137"}  |
    | 2bf7f2e0-3172-4c52-bcc1-40750492bca6 |      | fa:16:3e:ec:8f:87 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.136"}  |
    | 3299792b-07b3-48a0-9213-506034c05744 |      | fa:16:3e:88:ae:10 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.133"}  |
    | 421171b2-1abc-4423-8a46-c9ffa1ad11a0 |      | fa:16:3e:f0:d7:93 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.138"}  |
    | 421682b0-d76c-4d64-8cf7-a62c40733109 |      | fa:16:3e:fa:30:e4 | {"subnet_id": "956d685c-e7b3-420c-a127-3eedda941e4b", "ip_address": "192.168.112.2"} |
    | 55b5a275-7db8-4a31-8c84-089af254d3e1 |      | fa:16:3e:28:cd:fd | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.135"}  |
    | 6948a94a-b90d-4cbd-b8e5-a25ea78fc407 |      | fa:16:3e:17:1f:98 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.131"}  |
    | 70ef22b5-dd3a-4efe-9335-3c67a096fa22 |      | fa:16:3e:78:43:60 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.140"}  |
    | 7c1286e7-e606-46f5-976e-508de1872c8b |      | fa:16:3e:01:20:c4 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.134"}  |
    | 80bb3f49-8cf5-4841-afe1-fa60379bfeef |      | fa:16:3e:a5:14:61 | {"subnet_id": "5dd3709e-3171-40a5-891c-bc2d73c0a9a0", "ip_address": "192.168.111.1"} |
    | 99b119c9-5062-48e9-a0f4-55b36c70596f |      | fa:16:3e:fc:8e:c9 | {"subnet_id": "956d685c-e7b3-420c-a127-3eedda941e4b", "ip_address": "192.168.112.3"} |
    | a7863873-60b7-4372-9cd5-3a8a934a5ace |      | fa:16:3e:2f:23:69 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.139"}  |
    | bc753c4c-ad8b-4a62-aebf-4432e2376db4 |      | fa:16:3e:76:da:b7 | {"subnet_id": "5dd3709e-3171-40a5-891c-bc2d73c0a9a0", "ip_address": "192.168.111.2"} |
    | de4bb0a0-24ad-4aa6-9263-665bc9ff633b |      | fa:16:3e:75:c5:00 | {"subnet_id": "2f286f76-3532-41ab-81d8-6273ed5a3c6a", "ip_address": "172.16.0.130"}  |
    +--------------------------------------+------+-------------------+--------------------------------------------------------------------------------------+

root@node-15:~# neutron port-update 421682b0-d76c-4d64-8cf7-a62c40733109 -- --fixed_ips type=dict list=true ip_address=192.168.112.1

    Updated port: 421682b0-d76c-4d64-8cf7-a62c40733109


在Openstack上启动CoreOS集群
--------------------------

\# 设置认证权限

[root@node-9 ~]# cat creds-admin

    export OS_TENANT_NAME=admin
    export OS_USERNAME=admin
    export OS_PASSWORD=admin
    export OS_AUTH_URL="http://172.16.200.2:5000/v2.0/“

\# 使认证权限生效

[root@node-9 ~]# . creds-admin

\# 下载CoreOS镜像

[root@node-9 ~]# wget http://alpha.release.core-os.net/amd64-usr/current/coreos_production_openstack_image.img.bz2

\# 解压CoreOS镜像

[root@node-9 ~]# bunzip2 coreos_production_openstack_image.img.bz2

\# 通过glance将镜像导入Openstack中

[root@node-9 ~]# glance image-create --name "CoreOS Stable 410.0.0" \  
    --container-format bare \  
    --disk-format qcow2 \  
    --file coreos_production_openstack_image.img \  
    --is-public True  

    +------------------+--------------------------------------+
    | Property         | Value                                |
    +------------------+--------------------------------------+
    | checksum         | 2dc4d85f15f1de1c945cd2363418512b     |
    | container_format | bare                                 |
    | created_at       | 2014-09-03T05:08:26                  |
    | deleted          | False                                |
    | deleted_at       | None                                 |
    | disk_format      | qcow2                                |
    | id               | c3c0b86d-b2a6-4129-9bbd-b27fa4f88e06 |
    | is_public        | True                                 |
    | min_disk         | 0                                    |
    | min_ram          | 0                                    |
    | name             | CoreOS Stable 410.0.0                |
    | owner            | f51b22163f504dd6a6014f4700e9ee48     |
    | protected        | False                                |
    | size             | 448790528                            |
    | status           | active                               |
    | updated_at       | 2014-09-03T05:08:41                  |
    | virtual_size     | None                                 |
    +------------------+--------------------------------------+

\# 获取etcd token

[root@node-9 ~]# curl https://discovery.etcd.io/new

    https://discovery.etcd.io/c964af3ff154db796db834fedae038d4

\# 修改cloud-config.yaml文件，填入获取的token和要登录机器的ssh key

[root@node-9 ~]# cat cloud-config.yaml

    #cloud-config

    coreos:
      etcd:
        # generate a new token for each unique cluster from https://discovery.etcd.io/new
        discovery: https://discovery.etcd.io/c964af3ff154db796db834fedae038d4
        # multi-region and multi-cloud deployments need to use $public_ipv4
        addr: $private_ipv4:4001
        peer-addr: $private_ipv4:7001
      units:
        - name: etcd.service
          command: start
        - name: fleet.service
          command: start
    ssh_authorized_keys:
      # include one or more SSH public keys
      - ssh-rsa AAAAB3NzaC1yc2EAAAABIwAAAQEA2DwT6v5NUUBNBOjC4Z9ZCLLQW0efG+0gpLP5Axi9uslrfCIpVt4MwMktXFegI4eulqATlA+la7pw65MYF8Gm0H9binmqJkDyPilhQkgHltrHOibRww3SddBrQtPddzcD3UPMAWyOiq/3LUhHutMguoKvp2KFoMoakofy6LBsD2xrSnavqycVqw2yb9RDg3c4VVECnVpgDiPPxo8woBWL3PooWZDxEnTqNhm37NXrpRw0xOqLy0x44/1fucwBWpzTXLD2fGLz4JAcgJ8oZHv8hhgadMYMqRRrlYpq0Sx2HiTY/0Co3AzyzQ8kRK0gVLIm3eLE3yzEVEVsa2Bm7LUq4w== root@fuel.leju.com

\# 以上user-data会通过Openstack Metadata服务注入虚拟机，在虚拟机里访问Metadata接口可以看到注入的用户数据：

[root@node-9 ~]# curl http://169.254.169.254/openstack/2012-08-10/user_data

    #cloud-config

    coreos:
      etcd:
        # generate a new token for each unique cluster from https://discovery.etcd.io/new
        discovery: https://discovery.etcd.io/c964af3ff154db796db834fedae038d4
    ......

\# 列出网络信息

[root@node-9 ~]# nova net-list

    +--------------------------------------+-----------------+------+
    | ID                                   | Label           | CIDR |
    +--------------------------------------+-----------------+------+
    | 284d3f00-042b-41b2-bec4-f5bc7dcee037 | net_admin       | -    |
    | 35030315-0abb-4321-bd2d-fa02ecebe4a4 | net04           | -    |
    | 429f5040-ca24-42ff-9260-a5148ff47391 | net_op_leju_com | -    |
    | c4448c0d-f633-449a-861a-a39a304cad21 | net04_ext       | -    |
    +--------------------------------------+-----------------+------+

\# 列出虚拟机规格信息

[root@node-9 ~]# nova flavor-list

    +----+-----------+-----------+------+-----------+------+-------+-------------+-----------+
    | ID | Name      | Memory_MB | Disk | Ephemeral | Swap | VCPUs | RXTX_Factor | Is_Public |
    +----+-----------+-----------+------+-----------+------+-------+-------------+-----------+
    | 1  | m1.tiny   | 512       | 1    | 0         |      | 1     | 1.0         | True      |
    | 2  | m1.small  | 2048      | 20   | 0         |      | 1     | 1.0         | True      |
    | 3  | m1.medium | 4096      | 40   | 0         |      | 2     | 1.0         | True      |
    | 4  | m1.large  | 8192      | 80   | 0         |      | 4     | 1.0         | True      |
    | 5  | m1.xlarge | 16384     | 160  | 0         |      | 8     | 1.0         | True      |
    +----+-----------+-----------+------+-----------+------+-------+-------------+-----------+

\# 通过nova boot命令启动三个CoreOS虚拟机实例

[root@node-9 ~]# nova boot \  
 --user-data ./cloud-config.yaml \  
 --image c3c0b86d-b2a6-4129-9bbd-b27fa4f88e06 \  
 --key-name fuel \  
 --flavor m1.small \  
 --num-instances 3 \  
 --nic net-id=284d3f00-042b-41b2-bec4-f5bc7dcee037 \  
 --security-groups default coreos

    +--------------------------------------+--------------------------------------------------------------+
    | Property                             | Value                                                        |
    +--------------------------------------+--------------------------------------------------------------+
    | OS-DCF:diskConfig                    | MANUAL                                                       |
    | OS-EXT-AZ:availability_zone          | nova                                                         |
    | OS-EXT-SRV-ATTR:host                 | -                                                            |
    | OS-EXT-SRV-ATTR:hypervisor_hostname  | -                                                            |
    | OS-EXT-SRV-ATTR:instance_name        | instance-00000031                                            |
    | OS-EXT-STS:power_state               | 0                                                            |
    | OS-EXT-STS:task_state                | scheduling                                                   |
    | OS-EXT-STS:vm_state                  | building                                                     |
    | OS-SRV-USG:launched_at               | -                                                            |
    | OS-SRV-USG:terminated_at             | -                                                            |
    | accessIPv4                           |                                                              |
    | accessIPv6                           |                                                              |
    | adminPass                            | UWDaX8vxvzZn                                                 |
    | config_drive                         |                                                              |
    | created                              | 2014-09-03T06:14:10Z                                         |
    | flavor                               | m1.small (2)                                                 |
    | hostId                               |                                                              |
    | id                                   | a51d1492-9352-4979-8049-6e089af4fa65                         |
    | image                                | CoreOS Stable 410.0.0 (c3c0b86d-b2a6-4129-9bbd-b27fa4f88e06) |
    | key_name                             | fuel                                                         |
    | metadata                             | {}                                                           |
    | name                                 | coreos-a51d1492-9352-4979-8049-6e089af4fa65                  |
    | os-extended-volumes:volumes_attached | []                                                           |
    | progress                             | 0                                                            |
    | security_groups                      | default                                                      |
    | status                               | BUILD                                                        |
    | tenant_id                            | f51b22163f504dd6a6014f4700e9ee48                             |
    | updated                              | 2014-09-03T06:14:10Z                                         |
    | user_id                              | 8ad92b9cf95c4468b7718bbce22a39e0                             |
    +--------------------------------------+--------------------------------------------------------------+

\# 列出浮动IP地址

[root@node-9 ~]# nova floating-ip-list

    +----------------+-----------+----------------+-----------+
    | Ip             | Server Id | Fixed Ip       | Pool      |
    +----------------+-----------+----------------+-----------+
    | 172.16.200.138 |           | -              | net04_ext |
    | 172.16.200.134 |           | -              | net04_ext |
    | 172.16.200.137 |           | -              | net04_ext |
    | 172.16.200.135 |           | -              | net04_ext |
    | 172.16.200.131 |           | -              | net04_ext |
    | 172.16.200.132 |           | -              | net04_ext |
    | 172.16.200.136 |           | -              | net04_ext |
    | 172.16.200.139 |           | -              | net04_ext |
    | 172.16.200.133 |           | -              | net04_ext |
    | 172.16.200.140 |           | -              | net04_ext |
    +----------------+-----------+----------------+-----------+

\# 列出虚拟机

[root@node-9 ~]# nova list

    +--------------------------------------+---------------------------------------------+--------+------------+-------------+------------------------------------------+
    | ID                                   | Name                                        | Status | Task State | Power State | Networks                                 |
    +--------------------------------------+---------------------------------------------+--------+------------+-------------+------------------------------------------+
    | 3198baad-9a01-469f-af5b-13665b01c7f0 | coreos-3198baad-9a01-469f-af5b-13665b01c7f0 | ACTIVE | -          | Running     | net_admin=192.168.101.22                 |
    | 71a03186-1327-4608-bd66-b59f6c49c85c | coreos-71a03186-1327-4608-bd66-b59f6c49c85c | ACTIVE | -          | Running     | net_admin=192.168.101.23                 |
    | a51d1492-9352-4979-8049-6e089af4fa65 | coreos-a51d1492-9352-4979-8049-6e089af4fa65 | ACTIVE | -          | Running     | net_admin=192.168.101.21                 |
    | e2a5901b-cfd7-41d7-bd7f-f8e4e18cfc0f | vm_centos_7                                 | ACTIVE | -          | Running     | net04=192.168.100.12, 172.16.200.134     |
    +--------------------------------------+---------------------------------------------+--------+------------+-------------+------------------------------------------+

\# 为虚拟机绑定浮动IP

[root@node-9 ~]# nova add-floating-ip coreos-a51d1492-9352-4979-8049-6e089af4fa65 172.16.200.131

[root@node-9 ~]# nova add-floating-ip coreos-3198baad-9a01-469f-af5b-13665b01c7f0 172.16.200.132

[root@node-9 ~]# nova add-floating-ip coreos-71a03186-1327-4608-bd66-b59f6c49c85c 172.16.200.133

\# 界面中查看虚拟机情况

![Openstack CoreOS](/assets/images/14-09-10/openstack_coreos.png)

\# 通过浮动IP登录CoreOS虚拟机

    [root@fuel ~]# ssh core@172.16.200.131
    CoreOS (stable)
    core@coreos-a51d1492-9352-4979-8049-6e089af4fa65 ~ $ sudo su -
    coreos-a51d1492-9352-4979-8049-6e089af4fa65 ~ #

强制删除非正常状态的卷
--------------------

[root@node-9 ~]# . creds-admin

[root@node-9 ~]# cinder list

    +--------------------------------------+----------+----------------------------+------+-------------+----------+--------------------------------------+
    |                  ID                  |  Status  |        Display Name        | Size | Volume Type | Bootable |             Attached to              |
    +--------------------------------------+----------+----------------------------+------+-------------+----------+--------------------------------------+
    | 2f1219c1-9081-4a1e-ac4f-3b9e77b71bbb | creating | ost1_test-volume1530754005 |  1   |     None    |  false   |                                      |
    | 524bb475-d63f-4479-9a94-4d7eef87cf9a | creating |        domino_data         |  3   |     None    |  false   |                                      |
    | 937fedef-f9c0-4d8c-aca8-fc1aa6de27ab | creating |          vd_test           |  10  |     None    |  false   |                                      |
    | fcfc1fb1-5884-4ed9-a0f7-dd084c953ce4 |  in-use  |       vd_domino_test       |  3   |     None    |   true   | b46e1c74-f442-41ae-b480-fdd4d376dca5 |
    +--------------------------------------+----------+----------------------------+------+-------------+----------+--------------------------------------+

[root@node-9 ~]# cinder reset-state --state available 937fedef-f9c0-4d8c-aca8-fc1aa6de27ab

[root@node-9 ~]# cinder delete 937fedef-f9c0-4d8c-aca8-fc1aa6de27ab

[root@node-9 ~]# cinder list

    +--------------------------------------+----------+----------------------------+------+-------------+----------+--------------------------------------+
    |                  ID                  |  Status  |        Display Name        | Size | Volume Type | Bootable |             Attached to              |
    +--------------------------------------+----------+----------------------------+------+-------------+----------+--------------------------------------+
    | 2f1219c1-9081-4a1e-ac4f-3b9e77b71bbb | creating | ost1_test-volume1530754005 |  1   |     None    |  false   |                                      |
    | 524bb475-d63f-4479-9a94-4d7eef87cf9a | creating |        domino_data         |  3   |     None    |  false   |                                      |
    | fcfc1fb1-5884-4ed9-a0f7-dd084c953ce4 |  in-use  |       vd_domino_test       |  3   |     None    |   true   | b46e1c74-f442-41ae-b480-fdd4d376dca5 |
    +--------------------------------------+----------+----------------------------+------+-------------+----------+--------------------------------------+

强制删除ERROR状态的虚拟机
------------------------

[root@node-9 ~]# nova list

    +--------------------------------------+--------------+--------+------------+-------------+----------------------------------------------+
    | ID                                   | Name         | Status | Task State | Power State | Networks                                     |
    +--------------------------------------+--------------+--------+------------+-------------+----------------------------------------------+
    | c915770b-b2d3-4196-bb68-fc19aa2a6da9 | vm_cirros_op | ERROR  | deleting   | Shutdown    | net_op_leju_com=172.16.102.4, 172.16.200.142 |
    +--------------------------------------+--------------+--------+------------+-------------+----------------------------------------------+

[root@node-9 ~]# nova reset-state --active c915770b-b2d3-4196-bb68-fc19aa2a6da9

[root@node-9 ~]# nova show c915770b-b2d3-4196-bb68-fc19aa2a6da9

    +--------------------------------------+----------------------------------------------------------+
    | Property                             | Value                                                    |
    +--------------------------------------+----------------------------------------------------------+
    | OS-DCF:diskConfig                    | AUTO                                                     |
    | OS-EXT-AZ:availability_zone          | nova                                                     |
    | OS-EXT-SRV-ATTR:host                 | node-11.leju.com                                         |
    | OS-EXT-SRV-ATTR:hypervisor_hostname  | node-11.leju.com                                         |
    | OS-EXT-SRV-ATTR:instance_name        | instance-00000014                                        |
    | OS-EXT-STS:power_state               | 4                                                        |
    | OS-EXT-STS:task_state                | -                                                        |
    | OS-EXT-STS:vm_state                  | active                                                   |
    | OS-SRV-USG:launched_at               | 2014-09-02T07:46:46.000000                               |
    | OS-SRV-USG:terminated_at             | -                                                        |
    | accessIPv4                           |                                                          |
    | accessIPv6                           |                                                          |
    | config_drive                         |                                                          |
    | created                              | 2014-09-02T07:46:38Z                                     |
    | flavor                               | m1.tiny (1)                                              |
    | hostId                               | b51d791c8cc535dc723deed170df51ca5c415932f01b2c6b3fb67508 |
    | id                                   | c915770b-b2d3-4196-bb68-fc19aa2a6da9                     |
    | image                                | TestVM (722f1732-8a7a-4024-bd99-e039c2681360)            |
    | key_name                             | fuel                                                     |
    | metadata                             | {}                                                       |
    | name                                 | vm_cirros_op                                             |
    | net_op_leju_com network              | 172.16.102.4, 172.16.200.142                             |
    | os-extended-volumes:volumes_attached | []                                                       |
    | progress                             | 0                                                        |
    | status                               | ACTIVE                                                   |
    | tenant_id                            | 2e8def45720343fb9d648bd561a99c06                         |
    | updated                              | 2014-09-12T03:39:08Z                                     |
    | user_id                              | 181390a3b29d4e3fa9938aa7d65bb0b3                         |
    +--------------------------------------+----------------------------------------------------------+

[root@node-9 ~]# nova delete c915770b-b2d3-4196-bb68-fc19aa2a6da9

[root@node-9 ~]# nova list

    +----+------+--------+------------+-------------+----------+
    | ID | Name | Status | Task State | Power State | Networks |
    +----+------+--------+------------+-------------+----------+
    +----+------+--------+------------+-------------+----------+






