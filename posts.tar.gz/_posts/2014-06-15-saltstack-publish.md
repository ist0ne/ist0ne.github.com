---
layout: post
title: "Saltstack：代码部署系统搭建"
description: "本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。"
category: Saltstack
tags: [saltstack, salt, devops]
---

部署系统基于Salt Runner编写，Salt Runner使用salt-run命令执行的命令行工具，可以通过调用Salt API很轻松构建。Salt Runner与Salt的执行模块很像，但是在Salt Master上运行而非Salt Minion上。

#### 配置Salt Master

配置文件（/etc/salt/master.d/publish.conf）如下：

    svn:  
      username: 'publish'  # 定义svn用户名，用于检出代码  
      password: '#1qaz@WSX#ht'  # svn密码  
  
    publish:  
        master: 'admin.grid.mall.com'  # salt master主机名  
        cwd: '/data1/vhosts'  # 代码检出目录  

    projects:  
      www.mall.com:  # 定义项目名  
        remote: 'svn://172.16.100.81/www.mall.com' # svn存放路径  
        target:  # 定义代码部署列表 ip::rsync模块  
          - '172.16.100.21::www_mall_com'  
          - '172.16.100.22::www_mall_com'  
          - '172.16.100.23::www_mall_com'  

另外还要配置runner的放置目录：runner_dirs: [/srv/salt/_runners]，配置完成后要重启Puppet master。

#### Web前端部署rsync服务

rsync服务由/srv/salt/rsync模块进行管理，rsync配置文件(etc/rsyncd.conf)如下：

    # File Managed by Salt  
  
    uid = nobody  
    gid = nobody  
    use chroot = yes  
    max connections = 150  
    pid file = /var/run/rsyncd.pid  
    log file = /var/log/rsyncd.log  
    transfer logging = yes  
    log format = %t %a %m %f %b  
    syslog facility = local3  
    timeout = 300  
    incoming chmod = Du=rwx,Dog=rx,Fu=rw,Fgo=r  
    hosts allow=172.16.100.0/24  
  
    [www_mall_com]  
    path=/data1/vhosts/www.mall.com/htdocs/  
    read only=no  

#### 编写runner脚本

部署系统在Salt Master上把代码从SVN中检出，通过rsync命令部署到web前端。runner脚本(/srv/salt/_runners/publish.py)如下：

{% highlight python %}
# -*- coding: utf-8 -*-
'''
Functions to publish code on the master
'''

# Import salt libs
import salt.client
import salt.output


def push(project, output=True):
    '''
    publish code to web server.

    CLI Example:

    .. code-block:: bash

        salt-run publish.push project
    '''

    client = salt.client.LocalClient(__opts__['conf_file'])
    ret = client.cmd(__opts__['publish']['master'],
                      'svn.checkout',
                       [
                         __opts__['publish']['cwd'],
                         __opts__['projects'][project]['remote']
                       ],
                       kwarg={
                               'target':project,
                               'username':__opts__['svn']['username'],
                               'password':__opts__['svn']['password']
                             }
                    )

    if ret:
        msg = 'URL: %s\n%s' %(__opts__['projects'][project]['remote'], ret[__opts__['publish']['master']])
        ret = {'Check out code': msg}
    if output:
        salt.output.display_output(ret, '', __opts__)

    for target in __opts__['projects'][project]['target']:
        cmd = '/usr/bin/rsync -avz --exclude=".svn" %s/%s/trunk/* %s/' %(__opts__['publish']['cwd'], project, target)
        ret[target] = client.cmd(__opts__['publish']['master'],
                           'cmd.run',
                           [
                             cmd,
                           ],
                         )

        title = '\nSending file to %s' %target.split(':')[0]
        ret = {title: ret[target][__opts__['publish']['master']]}
        if output:
            salt.output.display_output(ret, '', __opts__)

    return ret
{% endhighlight %}

注意，一个项目（svn://172.16.100.81/www.mall.com ）通常会建立三个SVN子目录：trunk、branches、tags，上面脚本推送时只会将trunk目录下的代码部署到web前端。

#### 代码部署

    # salt-run publish.push www.mall.com

publish为上文runner脚本名，push为此脚本中定义的推送函数，www.mall.com为salt master中定义的项目名。

参考：  
[Salt Runners](http://docs.saltstack.com/en/latest/ref/runners/)  
[Python client API](http://docs.saltstack.com/en/latest/ref/clients/index.html)  

