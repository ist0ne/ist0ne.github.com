---
layout: post
title: "Kubernetes管理Docker集群"
description: "Kubernetes管理Docker集群"
category: 虚拟化
tags: [Openstack, KVM, Ceph, CoreOS, Docker]
---

Kubernetes是google开源的容器集群管理软件，本文介绍Kubernetes是如何管理Docker集群的创建、扩容、滚动升级及销毁的。

编译Docker镜像
-------------

\# 设置Docker hub用户变量和kubernetes master代理地址
[root@kubernetes update-demo]# export DOCKER_HUB_USER=ist0ne  
[root@kubernetes update-demo]# export KUBERNETES_MASTER=http://localhost:8001

\# 从Git hub上克隆GoogleCloudPlatform/kubernetes项目
[root@kubernetes ~]# git clone https://github.com/GoogleCloudPlatform/kubernetes.git

    Cloning into 'kubernetes'...
    remote: Counting objects: 14354, done.
    remote: Compressing objects: 100% (61/61), done.
    remote: Total 14354 (delta 23), reused 7 (delta 0)
    Receiving objects: 100% (14354/14354), 9.20 MiB | 24.00 KiB/s, done.
    Resolving deltas: 100% (8956/8956), done.
    Checking connectivity... done

[root@kubernetes ~]# cd /root/kubernetes/examples/update-demo

\# 编译docker镜像并推送到Docker hub
[root@kubernetes ~]# docker build -t update-demo-base images/base

\# 创建kube-demo Dockerfile
[root@kubernetes ~]# ls images/kube/

    Dockerfile  html

[root@kubernetes ~]# ls images/kube/html/

    cat.png  data.json  dog.png

[root@kubernetes ~]# cat images/kube/Dockerfile

    # Copyright 2014 Google Inc. All rights reserved.
    #
    # Licensed under the Apache License, Version 2.0 (the "License");
    # you may not use this file except in compliance with the License.
    # You may obtain a copy of the License at
    #
    #     http://www.apache.org/licenses/LICENSE-2.0
    #
    # Unless required by applicable law or agreed to in writing, software
    # distributed under the License is distributed on an "AS IS" BASIS,
    # WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    # See the License for the specific language governing permissions and
    # limitations under the License.

    FROM kube-demo-base

[root@kubernetes ~]# cat images/kube/html/data.json

    {
      "image": "cat.png"
    }

[root@kubernetes ~]# docker build -t "${DOCKER_HUB_USER}/kube-demo" images/kube  
[root@kubernetes ~]# docker push "${DOCKER_HUB_USER}/kube-demo"

启动本地代理
-----------

\# 如下修改local/script.js中得updateServer函数（注释35，38行，加入36，39行，修改41行为kube-demo）

     31 var updateServer = function($http, server) {
     32   $http.get(base + "pods/" + server.id)
     33     .success(function(data) {
     34       console.log(data);
     35       /* server.ip = data.currentState.hostIP; */
     36       server.ip = data.currentState.host;
     37       server.labels = data.labels;
     38       /* server.host = data.currentState.host.split('.')[0]; */
     39       server.host = data.currentState.host;
     40       server.status = data.currentState.status;
     41       server.dockerImage = data.currentState.info["kube-demo"].Config.Image;
     42       updateImage($http, server);
     43     })
     44     .error(function(data) {
     45       console.log(data);
     46     });
     47 };

\# 启动本地代理
[root@kubernetes update-demo]# kubecfg -h http://192.168.101.10:8000 -proxy -www local/
I0916 10:57:27.623345 09967 kubecfg.go:171] Starting to serve on localhost:8001

\# 访问http://localhost:8001/static/
此时网页上没有任何内容

创建Replication Controller
--------------------------

\# 启动两个kube-demo实例
[root@kubernetes update-demo]# kubecfg -p 8080:80 run $DOCKER_HUB_USER/kube-demo 2 kube-demo

    id: kube-demo
    creationTimestamp: 2014-09-16T08:27:03Z
    resourceVersion: 18384
    desiredState:
      replicas: 2
      replicaSelector:
        name: kube-demo
      podTemplate:
        desiredState:
          manifest:
            version: v1beta2
            id: ""
            volumes: []
            containers:
            - name: kube-demo
              image: ist0ne/kube-demo
              ports:
              - hostPort: 8080
                containerPort: 80
                protocol: TCP
          restartpolicy: {}
        labels:
          name: kube-demo
    labels:
      name: kube-demo

[root@kubernetes update-demo]# kubecfg list pods

    Name                                   Image(s)            Host                Labels
    ----------                             ----------          ----------          ----------
    c78a20be-3d86-11e4-b290-fa163e817aa4   ist0ne/kube-demo    192.168.101.13/     name=kube-demo,replicationController=kube-demo
    cec69804-3d86-11e4-b290-fa163e817aa4   ist0ne/kube-demo    192.168.101.12/     name=kube-demo,replicationController=kube-demo


\# 访问http://localhost:8001/static/
此时网页能看到两个实例正在启动

![kubernetes启动集群](/assets/images/14-09-17/kubernetes_resize2.png)

集群扩容
-------

\# 扩容到4个实例
[root@kubernetes update-demo]# kubecfg resize kube-demo 4

    id: kube-demo
    creationTimestamp: 2014-09-16T08:27:03Z
    resourceVersion: 22536
    desiredState:
      replicas: 4
      replicaSelector:
        name: kube-demo
      podTemplate:
        desiredState:
          manifest:
            version: v1beta2
            id: ""
            volumes: []
            containers:
            - name: kube-demo
              image: ist0ne/kube-demo
              ports:
              - hostPort: 8080
                containerPort: 80
                protocol: TCP
          restartpolicy: {}
        labels:
          name: kube-demo
    labels:
      name: kube-demo


[root@kubernetes update-demo]# kubecfg list pods

    Name                                   Image(s)            Host                Labels
    ----------                             ----------          ----------          ----------
    6cc17b5e-3d87-11e4-b290-fa163e817aa4   ist0ne/kube-demo    192.168.101.10/     name=kube-demo,replicationController=kube-demo
    7feddca9-3d87-11e4-b290-fa163e817aa4   ist0ne/kube-demo    192.168.101.11/     name=kube-demo,replicationController=kube-demo
    c78a20be-3d86-11e4-b290-fa163e817aa4   ist0ne/kube-demo    192.168.101.13/     name=kube-demo,replicationController=kube-demo
    cec69804-3d86-11e4-b290-fa163e817aa4   ist0ne/kube-demo    192.168.101.12/     name=kube-demo,replicationController=kube-demo

\# 访问http://localhost:8001/static/
此时网页能看到四个实例正在启动

![kubernetes扩容](/assets/images/14-09-17/kubernetes_resize4.png)

集群滚动升级
----------

\# 修改cat.png为dog.png
[root@kubernetes ~]# vi images/kube/html/data.json

    {
      "image": "dog.png"
    }

\# 编译ist0ne/kube-demo镜像，并推送到Docker hub
[root@kubernetes ~]# docker build -t "${DOCKER_HUB_USER}/kube-demo" images/kube  
[root@kubernetes ~]# docker push "${DOCKER_HUB_USER}/kube-demo"

\# 滚动升级
[root@kubernetes update-demo]# kubecfg -u 60s rollingupdate kube-demo

\# 访问http://localhost:8001/static/
此时网页能看到实例正在滚动升级

![kubernetes滚动升级1](/assets/images/14-09-17/kubernetes_rollingupdate_1.png)

![kubernetes滚动升级2](/assets/images/14-09-17/kubernetes_rollingupdate_2.png)

![kubernetes滚动升级3](/assets/images/14-09-17/kubernetes_rollingupdate_3.png)

终止集群
-------

\# 停止集群
[root@kubernetes update-demo]# kubecfg stop kube-demo
[root@kubernetes update-demo]# kubecfg rm kube-demo  

\# 也可以单独删除pod
[root@kubernetes update-demo]# kubecfg delete pods/6cc17b5e-3d87-11e4-b290-fa163e817aa4  



