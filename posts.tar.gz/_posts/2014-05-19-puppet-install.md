---
layout: post
title: "CentOS 6.4 Puppet 3.2.4安装"
description: "CentOS 6.4 Puppet 3.2.4安装"
category: Puppet
tags: [puppet, devops]
---

本文主要描述puppet的安装、加固、Puppet-dashboard安装、Puppet模块、hiera使用以及自定义facts。

##1、在Puppet Server和Puppet Client上关闭防火墙和selinux

清除防火墙设置
>iptables -F

保存设置
>/etc/init.d/iptables save 

设置selinux为disable
>vi /etc/sysconfig/selinux
SELINUX=disabled  

##2、在Puppet Server和Puppet Client上设置hosts，puppet通过主机名区分各节点

>10.10.10.10     puppet.leju.com

>10.10.10.11     zabbix.leju.com

##3、在Puppet Server和Puppet Client上安装puppetlabs.com仓库

>yum install -y http://yum.puppetlabs.com/el/6Server/products/x86_64/puppetlabs-release-6-7.noarch.rpm


##4、在Puppet Server上安装puppet-server

>yum install -y puppet-server 


##5、在Puppet Server上启动puppetmaster服务

>[root@puppet ~]# /etc/init.d/puppetmaster start

>启动 puppetmaster：                                        [确定]

##6、在Puppet Server上查看证书

>[root@puppet ~]# puppet cert list --all

>\+ "puppet.leju.com" (SHA256) 44:E4:8C:B2:F9:9D:38:3B:7C:68:7B:D3:21:0D:2F:64:B5:FB:8C:F7:78:85:BE:50:D9:A2:C7:CA:67:98:13:00 (alt names: "DNS:puppet", "DNS:puppet.leju.com")

##7、使用apache + passenger 运行puppet-server

>yum install httpd httpd-devel ruby-devel mod_ssl make gcc gcc-c++ curl-devel openssl-devel zlib-devel

安装rack和passenger

>[root@puppet ~]# gem install -v=1.5.2 rack

>Successfully installed rack-1.5.2

>1 gem installed

>Installing ri documentation for rack-1.5.2...

>Installing RDoc documentation for rack-1.5.2...


>[root@puppet ~]# gem install -v=4.0.14 passenger

>Building native extensions.  This could take a while...

>Successfully installed passenger-4.0.14

>1 gem installed

>Installing ri documentation for passenger-4.0.14...

>Installing RDoc documentation for passenger-4.0.14...

编译passenger
>passenger-install-apache2-module

配置Puppet rack应用：
{% highlight bash %}
mkdir -p /etc/puppet/rack/
mkdir /etc/puppet/rack/public /etc/puppet/rack/tmp
cp /usr/share/puppet/ext/rack/example-passenger-vhost.conf /etc/httpd/conf.d/puppetmasterd.conf
cp /usr/share/puppet/ext/rack/config.ru /etc/puppet/rack/ 
chown -R puppet.puppet /etc/puppet/rack/

ln -s /var/lib/puppet/ssl/ /etc/puppet/ 

[root@puppet ~]# vi /etc/httpd/conf.d/passenger.conf
LoadModule passenger_module /usr/lib/ruby/gems/1.8/gems/passenger-4.0.14/buildout/apache2/mod_passenger.so
PassengerRoot /usr/lib/ruby/gems/1.8/gems/passenger-4.0.14
PassengerDefaultRuby /usr/bin/ruby
PassengerMaxPoolSize 30
PassengerPoolIdleTime 1500
PassengerMaxRequests 1000
PassengerStatThrottleRate 120
{% endhighlight %}

如下修改puppetmasterd.conf 
{% highlight ruby %}
vi /etc/httpd/conf.d/puppetmasterd.conf 

Listen 8140

<VirtualHost *:8140>
        SSLEngine on
        SSLProtocol -ALL +SSLv3 +TLSv1
        SSLCipherSuite ALL:!ADH:RC4+RSA:+HIGH:+MEDIUM:-LOW:-SSLv2:-EXP

        SSLCertificateFile      /etc/puppet/ssl/certs/puppet.leju.com.pem
        SSLCertificateKeyFile   /etc/puppet/ssl/private_keys/puppet.leju.com.pem
        SSLCertificateChainFile /etc/puppet/ssl/ca/ca_crt.pem
        SSLCACertificateFile    /etc/puppet/ssl/ca/ca_crt.pem
        # If Apache complains about invalid signatures on the CRL, you can try disabling
        # CRL checking by commenting the next line, but this is not recommended.
        SSLCARevocationFile     /etc/puppet/ssl/ca/ca_crl.pem
        SSLVerifyClient optional
        SSLVerifyDepth  1
        # The `ExportCertData` option is needed for agent certificate expiration warnings
        SSLOptions +StdEnvVars +ExportCertData

        # This header needs to be set if using a loadbalancer or proxy
        RequestHeader unset X-Forwarded-For

        RequestHeader set X-SSL-Subject %{SSL_CLIENT_S_DN}e
        RequestHeader set X-Client-DN %{SSL_CLIENT_S_DN}e
        RequestHeader set X-Client-Verify %{SSL_CLIENT_VERIFY}e

        DocumentRoot /etc/puppet/rack/public/
        RackBaseURI /
        <Directory /etc/puppet/rack/public/>
                Options None
                AllowOverride None
                Order allow,deny
                allow from all
        </Directory>
</VirtualHost>
{% endhighlight %}

设置apache以puppet用户启动
{% highlight bash %}
vi /etc/httpd/conf/httpd.conf 
User puppet
Group puppet
{% endhighlight %}

设置 /etc/puppet/puppet.conf
{% highlight ruby %}
[root@puppet ~]# vi /etc/puppet/puppet.conf
[main]
    # The Puppet log directory.
    # The default value is '$vardir/log'.
    logdir = /var/log/puppet

    # Where Puppet PID files are kept.
    # The default value is '$vardir/run'.
    rundir = /var/run/puppet

    # Where SSL certificates are kept.
    # The default value is '$confdir/ssl'.
    ssldir = $vardir/ssl

[master]
    ssl_client_header = SSL_CLIENT_S_DN
    ssl_client_verify_header = SSL_CLIENT_VERIFY
    autosign = true
    reports = store

[agent]
    # The file in which puppetd stores a list of the classes
    # associated with the retrieved configuratiion.  Can be loaded in
    # the separate ``puppet`` executable using the ``--loadclasses``
    # option.
    # The default value is '$confdir/classes.txt'.
    classfile = $vardir/classes.txt

    # Where puppetd caches the local configuration.  An
    # extension indicating the cache format is added automatically.
    # The default value is '$confdir/localconfig'.
    localconfig = $vardir/localconfig
{% endhighlight %}

配置 /etc/sysconfig/puppetmaster
{% highlight ruby %}
[root@puppet ~]# vi /etc/sysconfig/puppetmaster
# Location of the main manifest
#PUPPETMASTER_MANIFEST=/etc/puppet/manifests/site.pp

# Where to log general messages to.
# Specify syslog to send log messages to the system log.
#PUPPETMASTER_LOG=syslog

# You may specify an alternate port on which your puppetmaster should listen. Default is: 8140
# An example with puppetmaster on a different port, run with standard webrick servertype
#PUPPETMASTER_PORTS="8141"

# You may specify other parameters to the puppetmaster here
#PUPPETMASTER_EXTRA_OPTS=--no-ca
PUPPETMASTER_EXTRA_OPTS="--reports store"
{% endhighlight %}

配置文件服务
{% highlight bash %}
[root@puppet ~]# vi /etc/puppet/fileserver.conf 
 [files]
    path /etc/puppet/files
    allow *

[modules]
    allow *

[plugins]
    allow *
{% endhighlight %}

创建文件发布目录
>mkdir -p /etc/puppet/files 

##8、在Puppet Server上配置puppet manifests和module

>[root@puppet puppet]# cd manifests/

创建site.pp，此为puppet入口配置文件：
{% highlight bash %}
[root@puppet manifests]# vi site.pp
import "roles.pp"
import "nodes.pp"

# General settings for standard types
Exec { path => "/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin" }

filebucket { main: server => "puppet.leju.com", path => false }
File { backup => main }
{% endhighlight %}

创建roles.pp，用于定义服务器角色：
{% highlight ruby %}
[root@puppet manifests]# vi roles.pp
class baseclass {
        include test
}
{% endhighlight %}

创建nodes.pp，用于配置服务器节点：
{% highlight ruby %}
[root@puppet manifests]# vi nodes.pp
node 'basenode' {
        include baseclass
}

node 'zabbix.leju.com' inherits basenode {
        tag("test")
}
{% endhighlight %}

创建一个test模块：
{% highlight bash %}
[root@puppet manifests]# cd ..
[root@puppet puppet]# mkdir modules
[root@puppet modules]# mkdir -p test/manifests/
[root@puppet modules]# mkdir test/files/
[root@puppet modules]# cd test/files/
[root@puppet files]# vi test.txt
test line！
{% endhighlight %}

创建test类，用来下发一个文件到客户端：
{% highlight ruby %}
[root@puppet files]# cd ../manifests/
[root@puppet manifests]# vi init.pp
class test {
        file { "/tmp/test.txt":
                ensure  => present,
                group   => "root",
                owner   => "root",
                mode    => "0644",
                source  => "puppet:///test/test.txt"
        }
}
{% endhighlight %}

##9、启动puppet server

开机启动httpd服务：

>[root@puppet ~]# chkconfig --level 2345 httpd on

启动apache服务
{% highlight bash %}
[root@puppet ~]# /etc/init.d/httpd start 
[root@puppet ~]# netstat -tunlp
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address               Foreign Address             State       PID/Program name
tcp        0      0 127.0.0.1:37964             0.0.0.0:*                   LISTEN      7358/Passenger Rack
tcp        0      0 :::8140                     :::*                        LISTEN      7297/httpd
{% endhighlight %}

##10、配置puppet client

安装puppet
>[root@zabbix ~]# yum install -y puppet

配置/etc/puppet/puppet.conf
{% highlight bash %}
[root@zabbix ~]# vi /etc/puppet/puppet.conf
[main]
    # The Puppet log directory.
    # The default value is '$vardir/log'.
    logdir = /var/log/puppet

    # Where Puppet PID files are kept.
    # The default value is '$vardir/run'.
    rundir = /var/run/puppet

    # Where SSL certificates are kept.
    # The default value is '$confdir/ssl'.
    ssldir = $vardir/ssl

[agent]
    # The file in which puppetd stores a list of the classes
    # associated with the retrieved configuratiion.  Can be loaded in
    # the separate ``puppet`` executable using the ``--loadclasses``
    # option.
    # The default value is '$confdir/classes.txt'.
    classfile = $vardir/classes.txt

    # Where puppetd caches the local configuration.  An
    # extension indicating the cache format is added automatically.
    # The default value is '$confdir/localconfig'.
    localconfig = $vardir/localconfig

    report = true  # 设置发送报告

    listen = true  # 设置为守护进程

    # 设置puppet server地址
    server = puppet.leju.com


    # 禁用插件同步，puppet 3.0默认开启，如果没有配置插件会报错
    pluginsync=false
{% endhighlight %}

配置/etc/sysconfig/puppet
{% highlight bash %}
[root@zabbix ~]# vi /etc/sysconfig/puppet
# The puppetmaster server
PUPPET_SERVER=puppet.leju.com

# If you wish to specify the port to connect to do so here
#PUPPET_PORT=8140

# Where to log to. Specify syslog to send log messages to the system log.
#PUPPET_LOG=/var/log/puppet/puppet.log

# You may specify other parameters to the puppet client here
#PUPPET_EXTRA_OPTS=--waitforcert=500

[root@zabbix ~]# vi namespaceauth.conf
[puppetrunner]    allow puppet.leju.com    
[root@zabbix ~]#  vi auth.conf
# 在最后一行添加allow *
......
path /
auth any

allow *
{% endhighlight %}

设置puppet开机自动启动
>[root@zabbix ~]# chkconfig puppet on

测试客户端
>[root@zabbix ~]# puppet agent --test --debug  

如果Puppet Server没有设置：autosign = true，需要在Puppet Server上执行：
{% highlight bash %}
[root@puppet ~]# puppet cert list
zabbix.leju.com
[root@puppet ~]# puppet cert sign zabbix.leju.com
{% endhighlight %}

这样为zabbix.leju.com签名。然后回到客户端再次执行：
>[root@zabbix ~]# puppet agent --test --debug 

文件已同步
{% highlight bash %}
[root@zabbix ~]# cat /tmp/test.txt
test line.
{% endhighlight %}

启动puppet客户端服务，自动抓取配置
{% highlight bash %}
[root@zabbix ~]# service puppet start
[root@zabbix ~]# netstat -tunlp
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address               Foreign Address             State       PID/Program name
tcp        0      0 0.0.0.0:8139                0.0.0.0:*                   LISTEN      3413/ruby
{% endhighlight %}

也可以在Puppet Server上进行推送：
{% highlight bash %}
[root@puppet ~]# puppet kick -d --host zabbix.leju.com
Triggering zabbix.leju.com
Getting status
status is success
zabbix.leju.com finished with exit code 0
Finished
{% endhighlight %}

返回0说明触发客户端上的puppetd成功。

##11、在Puppet Server上安装puppetdb

安装puppetdb
{% highlight bash %}
[root@puppet ~]# puppet resource package puppetdb ensure=latest
Notice: /Package[puppetdb]/ensure: created
package { 'puppetdb':
  ensure => '1.4.0-1.el6',
}
{% endhighlight %}

启动puppetdb并设置开机自启动
{% highlight bash %}
[root@puppet ~]# puppet resource service puppetdb ensure=running enable=true
Notice: /Service[puppetdb]/ensure: ensure changed 'stopped' to 'running'
service { 'puppetdb':
  ensure => 'running',
  enable => 'true',
}
{% endhighlight %}

查看启动日志
{% highlight bash %}
[root@puppet ~]# cat /var/log/puppetdb/puppetdb.log
2013-08-25 09:46:29,823 INFO  [main] [cli.services] Starting 1 command processor threads
2013-08-25 09:46:29,845 INFO  [main] [cli.services] Starting query server
2013-08-25 09:46:29,870 INFO  [pool-2-thread-1] [cli.services] Starting database garbage collection
2013-08-25 09:46:29,904 INFO  [clojure-agent-send-off-pool-2] [server.Server] jetty-7.x.y-SNAPSHOT
2013-08-25 09:46:29,906 INFO  [pool-2-thread-1] [cli.services] Finished database garbage collection
2013-08-25 09:46:29,921 INFO  [pool-2-thread-1] [cli.services] Starting sweep of stale reports (threshold: 14 days)
2013-08-25 09:46:29,933 INFO  [pool-2-thread-1] [cli.services] Finished sweep of stale reports (threshold: 14 days)
2013-08-25 09:46:30,059 INFO  [clojure-agent-send-off-pool-2] [server.AbstractConnector] Started SelectChannelConnector@localhost:8080
2013-08-25 09:46:30,515 INFO  [clojure-agent-send-off-pool-2] [ssl.SslContextFactory] Enabled Protocols [SSLv2Hello, SSLv3, TLSv1] of [SSLv2Hello, SSLv3, TLSv1]
2013-08-25 09:46:30,530 INFO  [clojure-agent-send-off-pool-2] [server.AbstractConnector] Started SslSelectChannelConnector@puppet.leju.com:8081
{% endhighlight %}

查看启动端口
{% highlight bash %}
[root@puppet ~]# netstat -tunlp
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address               Foreign Address             State       PID/Program name

tcp        0      0 ::ffff:127.0.0.1:8080       :::*                        LISTEN      6757/java
tcp        0      0 ::ffff:10.10.10.10:8081     :::*                        LISTEN      6757/java
{% endhighlight %}

配置puppet server连接到puppetdb
安装puppetdb-terminus插件
{% highlight bash %}
[root@puppet ~]# puppet resource package puppetdb-terminus ensure=latest
Notice: /Package[puppetdb-terminus]/ensure: created
package { 'puppetdb-terminus':
[main]
  ensure => '1.4.0-1.el6',
}
{% endhighlight %}

在/etc/puppet下新建puppetdb.conf，并输入puppetdb server和port
{% highlight bash %}
[root@puppet ~]# cd /etc/puppet
[root@puppet puppet]# vi puppetdb.conf
[main]
server = puppet.leju.com
port = 8081
{% endhighlight %}

配置puppet server连接到puppetdb
{% highlight bash %}
[root@puppet puppet]# vi puppet.conf
[master]
    ……
    storeconfigs = true
    storeconfigs_backend = puppetdb
{% endhighlight %}

在/etc/puppet下新建routes.yaml
{% highlight bash %}
[root@puppet puppet]# vi routes.yaml
---
master:
  facts:
    terminus: puppetdb
    cache: yaml
{% endhighlight %}

重启puppet server
{% highlight bash %}
[root@puppet puppet]# /etc/init.d/httpd restart
停止 httpd：                                               [确定]
正在启动 httpd：                                           [确定]
{% endhighlight %}

在puppet客户端（[zabbix.leju.com）执行
{% highlight bash %}
[root@zabbix ~]# puppet agent --test --debug
{% endhighlight %}
 
查看日志，发现zabbix.leju.com已推送facts和catalog到puppetdb
{% highlight bash %}
[root@puppet puppet]# tail -f /var/log/puppetdb/puppetdb.log

2013-08-25 10:12:52,606 INFO  [command-proc-46] [puppetdb.command] [af698348-275d-45ac-9ea9-017c4b1e6947] [replace facts] zabbix.leju.com
2013-08-25 10:12:53,824 INFO  [command-proc-46] [puppetdb.command] [8d7029f9-e147-4b9f-8076-4b26e21d7a9f] [replace catalog] zabbix.leju.com
{% endhighlight %}

参考文档：http://docs.puppetlabs.com/puppetdb/1.4/install_from_packages.html 

##12、在Puppet Server上安装puppet-dashboard

安装MySQL
{% highlight bash %}
[root@puppet ~]# yum install -y mysql mysql-devel mysql-server
{% endhighlight %}

配置MySQL
{% highlight bash %}
[root@puppet ~]# vi /etc/my.cnf
[mysqld]
bind=10.10.10.10
datadir=/var/lib/mysql
socket=/var/lib/mysql/mysql.sock
user=mysql
# Disabling symbolic-links is recommended to prevent assorted security risks
symbolic-links=0
# Allowing 32MB allows an occasional 17MB row with plenty of spare room
max_allowed_packet = 32M

[mysqld_safe]
log-error=/var/log/mysqld.log
pid-file=/var/run/mysqld/mysqld.pid
{% endhighlight %}

启动MySQL
{% highlight bash %}
[root@puppet ~]# /etc/init.d/mysqld start

正在启动 mysqld：                                          [确定]
[root@puppet ~]# netstat -tunlp
Active Internet connections (only servers)
Proto Recv-Q Send-Q Local Address               Foreign Address             State       PID/Program name
tcp        0      0 10.10.10.10:3306            0.0.0.0:*                   LISTEN      11677/mysqld
{% endhighlight %}

开机自动启动MySQL
{% highlight bash %}
[root@puppet ~]# chkconfig --level 2345 mysqld on
{% endhighlight %}

创建一个dashboard数据库
{% highlight bash %}
[root@puppet ~]# mysql -uroot
Welcome to the MySQL monitor.  Commands end with ; or \g.
Your MySQL connection id is 2
Server version: 5.1.69 Source distribution

Copyright (c) 2000, 2013, Oracle and/or its affiliates. All rights reserved.

Oracle is a registered trademark of Oracle Corporation and/or its
affiliates. Other names may be trademarks of their respective
owners.

Type 'help;' or '\h' for help. Type '\c' to clear the current input statement.

mysql> CREATE DATABASE dashboard CHARACTER SET utf8;
Query OK, 1 row affected (0.00 sec)

mysql> CREATE USER 'dashboard'@'10.10.10.10' IDENTIFIED BY 'dashboard@puppet$';
Query OK, 0 rows affected (0.00 sec)

mysql> GRANT ALL PRIVILEGES ON dashboard.* TO 'dashboard'@'10.10.10.10';
Query OK, 0 rows affected (0.00 sec)

mysql> FLUSH PRIVILEGES;
Query OK, 0 rows affected (0.00 sec)

mysql> quit
Bye
{% endhighlight %}

安装puppet-dashboard
{% highlight bash %}
[root@puppet ~]# yum install -y puppet-dashboard
{% endhighlight %}

配置Dashboard

编辑 /usr/share/puppet-dashboard/config/database.yml
{% highlight bash %}
[root@puppet ~]# vi /usr/share/puppet-dashboard/config/database.yml
production:
  database: dashboard
  username: dashboard
  password: dashboard@puppet$
  encoding: utf8
  adapter: mysql
  host: 10.10.10.10
{% endhighlight %}

修改时区 /usr/share/puppet-dashboard/config/environment.rb
{% highlight bash %}
[root@puppet ~]# vi /usr/share/puppet-dashboard/config/environment.rb
# config.time_zone = 'UTC'
config.time_zone = 'Beijing'
{% endhighlight %}

初始化数据库
{% highlight bash %}
[root@puppet ~]# cd /usr/share/puppet-dashboard/
[root@puppet puppet-dashboard]# rake RAILS_ENV=production db:migrate
{% endhighlight %}

配置apache
{% highlight bash %}
[root@puppet puppet-dashboard]# vi /etc/httpd/conf.d/dashboard.conf
<VirtualHost *:80>
   ServerName puppet.leju.com
   DocumentRoot "/usr/share/puppet-dashboard/public/"
   <Directory "/usr/share/puppet-dashboard/public/">
      Options None
      AllowOverride AuthConfig
      Order allow,deny
      allow from all
   </Directory>
   ErrorLog /var/log/httpd/puppet.leju.com_error.log
   LogLevel warn
   CustomLog /var/log/httpd/puppet.leju.com_access.log combined
   ServerSignature On
</VirtualHost>
{% endhighlight %}

配置Puppet报告到Dashboard
{% highlight bash %}
[root@puppet puppet-dashboard]# cd
[root@puppet ~]# vi /etc/puppet/puppet.conf
[master]
    ssl_client_header = SSL_CLIENT_S_DN
    ssl_client_verify_header = SSL_CLIENT_VERIFY
    autosign = true
    reports = store, http
    reporturl = http://puppet.leju.com/reports/upload
    ......
{% endhighlight %}

配置/etc/sysconfig/puppetmaster
{% highlight bash %}
[root@puppet ~]# vi /etc/sysconfig/puppetmaster
PUPPETMASTER_EXTRA_OPTS="--reports store, puppet_dashboard"
{% endhighlight %}

重启apache使配置生效
{% highlight bash %}
[root@puppet ~]# /etc/init.d/httpd restart
停止 httpd：                                               [确定]
正在启动 httpd：                                           [确定]
{% endhighlight %}

导入已有报告
{% highlight bash %}
[root@puppet ~]# cd /usr/share/puppet-dashboard
[root@puppet puppet-dashboard]#
[root@puppet puppet-dashboard]# rake RAILS_ENV=production reports:import
Importing 29 reports from /var/lib/puppet/reports in the background
Importing:     100% |#############################################################################################################################################| Time: 00:00:00
29 of 29 reports queued
{% endhighlight %}

启动dashboard报告分析进程
{% highlight bash %}
[root@puppet ~]# chown -R puppet-dashboard /usr/share/puppet-dashboard/tmp/pids/
[root@puppet ~]# /etc/init.d/puppet-dashboard-workers start
正在启动 puppet-dashboard-workers：                        [确定]
[root@puppet ~]# chkconfig --level 2345 puppet-dashboard-workers on
{% endhighlight %}

以上启动脚本有问题，如下启动：
{% highlight bash %}
env RAILS_ENV=production /usr/share/puppet-dashboard/script/delayed_job -p dashboard -n 4 -m start
{% endhighlight %}

配置Inventory服务（使用puppetdb）

配置/usr/share/puppet-dashboard/config/settings.yml
{% highlight bash %}
[root@puppet ~]# vi /usr/share/puppet-dashboard/config/settings.yml
# Node name to use when contacting the puppet master.  This is the
# CN that is used in Dashboard's certificate.
cn_name: 'puppet.leju.com'


ca_crl_path: 'certs/puppet.leju.com.ca_crl.pem'


ca_certificate_path: 'certs/puppet.leju.com.ca_cert.pem'


certificate_path: 'certs/puppet.leju.com.cert.pem'


private_key_path: 'certs/puppet.leju.com.private_key.pem'


public_key_path: 'certs/puppet.leju.com.public_key.pem'

# Hostname of the certificate authority.
ca_server: 'puppet.leju.com'

# Port for the certificate authority.
ca_port: 8140

# Key length for SSL certificates
key_length: 1024

# The "inventory service" allows you to connect to a puppet master to retrieve and node facts
enable_inventory_service: true

# Hostname of the inventory server.
inventory_server: 'puppet.leju.com'

# Port for the inventory server.
inventory_port: 8140

# Set this to true to allow Dashboard to display diffs on files that
# are archived in the file bucket.
use_file_bucket_diffs: true

# Hostname of the file bucket server.
file_bucket_server: 'puppet.leju.com'

# Port for the file bucket server.
file_bucket_port: 8140
{% endhighlight %}

配置puppet授权访问文件
{% highlight bash %}
[root@puppet ~]# vi /etc/puppet/auth.conf
……

path /facts
auth any
allow *

path /facts_search
allow *

# deny everything else; this ACL is not strictly necessary, but
# illustrates the default policy.
path /
auth any
{% endhighlight %}

重启puppet server
{% highlight bash %}
[root@puppet ~]# /etc/init.d/httpd restart
停止 httpd：                                               [确定]
正在启动 httpd：                                           [确定]
{% endhighlight %}

访问puppet dashboard


参考文档：http://docs.puppetlabs.com/guides/inventory_service.htmlInventory 

##13、编写Puppet模块
可以从http://forge.puppetlabs.com/ 和https://github.com查找共享的Puppet模块。

以ntp模块为例，从github下载代码放到/etc/puppet/modules/
{% highlight bash %}
[root@puppet ~]# cd /etc/puppet/modules/
[root@puppet modules]# git clone https://github.com/puppetlabs/puppetlabs-ntp.git
[root@puppet modules]# mv puppetlabs_ntp ntp

# 下载ntp依赖的stdlib模块
[root@puppet modules]# git clone https://github.com/puppetlabs/puppetlabs-stdlib.git
[root@puppet modules]# mv puppetlabs_stdlib stdlib
{% endhighlight %}

参考文档：http://docs.puppetlabs.com/puppet/3/reference/modules_fundamentals.html 

参考文档：stdlib

http://puppetlabs.com/blog/module-of-the-week-puppetlabsstdlib-puppet-labs-standard-library

http://puppetlabs.com/blog/module-of-the-week-puppetlabs-stdlib-puppet-labs-standard-library-part-2 

http://puppetlabs.com/blog/module-of-the-week-puppetlabsstdlib-puppetlabs-standard-library-part-3

http://puppetlabs.com/blog/module-of-the-week-puppetlabs-stdlib-puppet-labs-standard-library-part-4

##14、使用hiera
将数据放到hiera中可以更好的复用puppet代码。

安装hiera

hiera已经内置在puppet 3.x中，如果puppet版本是2.7.x需要单独安装hiera、hiera-puppet 
{% highlight bash %}
puppet resource package hiera ensure=installed
puppet resource package hiera-puppet ensure=installed
{% endhighlight %}

参考文档：hiera安装http://docs.puppetlabs.com/hiera/1/installing.html 

配置hiera
{% highlight bash %}
[root@puppet ~]# cat /etc/puppet/hiera.yaml
---
:backends:
  - yaml
:yaml:
  :datadir: /etc/puppet/hieradata
:hierarchy:
  - node/%{::fqdn}
  - idc/%{::idc}
  - environment/%{::environment}
  - osfamily/%{osfamily}
  - common
:merge_behavior:
  - deeper
{% endhighlight %}

如果merge_behavior使用depper需要安装deep_merge，切hiera版本大于等于1.2.0
{% highlight bash %}
[root@puppet ~]# gem install deep_merge
Successfully installed deep_merge-1.0.0
1 gem installed
Installing ri documentation for deep_merge-1.0.0...
Installing RDoc documentation for deep_merge-1.0.0...
{% endhighlight %}

创建相应的目录
{% highlight bash %}
[root@puppet ~]# ls /etc/puppet/hieradata/
environment  idc  node  osfamily
{% endhighlight %}

为配置文件创建连接，hiera命令行使用/etc/hiera.yaml配置文件
{% highlight bash %}
[root@puppet ~]# ln -s /etc/puppet/hiera.yaml /etc/hiera.yaml 
{% endhighlight %}

参考文档：

Hiera配置：http://docs.puppetlabs.com/hiera/1/configuring.html

创建Hierarchies： http://docs.puppetlabs.com/hiera/1/hierarchy.html 

yaml coolbook： http://www.yaml.org/YAML_for_ruby.html
 
编写数据源
{% highlight bash %}
[root@puppet puppet]# cat hieradata/node/puppet.leju.com.yaml
\---
ntp::package_ensure: present
ntp::service_enable: true

ntp::servers:
  - 0.asia.pool.ntp.org
  - 1.asia.pool.ntp.org
[root@puppet puppet]# cat hieradata/node/zabbix.leju.com.yaml
\---
ntp::package_ensure: latest
ntp::service_enable: true

ntp::servers:
  - puppet.leju.com
  - 0.asia.pool.ntp.org
  - 1.asia.pool.ntp.org
[root@puppet puppet]# cat hieradata/idc/m5.yaml
\---
ntp::package_ensure: latest
ntp::service_enable: true

ntp::servers:
  - puppet.leju.com
  - zabbix.leju.com
[root@puppet puppet]# cat hieradata/common.yaml
\---
ntp::package_ensure: latest
ntp::service_enable: true

ntp::servers:
  - 4.asia.pool.ntp.org
  - 5.asia.pool.ntp.org
{% endhighlight %}

测试数据源
{% highlight bash %}
[root@puppet puppet]# hiera ntp::servers ::fqdn=puppet.leju.com
["0.asia.pool.ntp.org", "1.asia.pool.ntp.org"]
[root@puppet puppet]# vi hieradata/node/puppet.leju.com.yaml
[root@puppet puppet]# hiera ntp::package_ensure ::fqdn=puppet.leju.com
present
[root@puppet puppet]# hiera ntp::servers ::fqdn=zabbix.leju.com
["puppet.leju.com", "0.asia.pool.ntp.org", "1.asia.pool.ntp.org"]
[root@puppet puppet]# hiera ntp::package_ensure ::fqdn=zabbix.leju.com
latest
[root@puppet puppet]# hiera ntp::servers ::fqdn=node.leju.com ::idc=m5
["puppet.leju.com", "zabbix.leju.com"]
[root@puppet puppet]# hiera ntp::servers ::fqdn=node.leju.com
["4.asia.pool.ntp.org", "5.asia.pool.ntp.org"]
[root@puppet puppet]# hiera ntp::package_ensure ::fqdn=node.leju.com
latest
{% endhighlight %}

puppet.leju.com在idc m5机房，使用0.asia.pool.ntp.org和1.asia.pool.ntp.org ntp server，不自动升级
zabbix.leju.com在idc m5机房，使用puppet.leju.com 0.asia.pool.ntp.org 和1.asia.pool.ntp.org ntp server
node.leju.com在idc m5机房，使用puppet.leju.com和zabbix.leju.com ntp server
其他机房默认使用4.asia.pool.ntp.org和5.asia.pool.ntp.org

参考文档：

编写数据源: http://docs.puppetlabs.com/hiera/1/data_sources.html

hiera应用完整实例: http://docs.puppetlabs.com/hiera/1/complete_example.html 

##15、 在上文中用到的 facts idc需要自定义

Stone:puppet dongliang$ cat modules/tags/lib/facter/idc.rb

{% highlight ruby %}
# Fact: idc
#
# Purpose: return idc
#

require 'facter'

idc = ""

network_eth0 = Facter.value('network_eth0')

case network_eth0
when /60\.38\.244|172\.16\.244/
    idc = "tanggu"
when /121\.24\.32|10\.71\.32/
    idc = "qixinggang"
when /58\.93\.214|172\.16\.215/
    idc = "m5"
when /61\.182\.207|172\.16\.51/
    idc = "qinzhou"
when /10\.26\.0|10\.27\.0/
    idc = "huayuan"
end

Facter.add(:idc) do
    setcode { idc }
end
{% endhighlight %}

参考文档：自定义factshttp://docs.puppetlabs.com/guides/custom_facts.html 






