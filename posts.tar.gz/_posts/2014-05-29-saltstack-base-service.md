---
layout: post
title: "Saltstack：基础服务部署"
description: "本文以一个小的电商网站（www.mall.com）为例，讲述Saltstack在真实场景中的应用。"
category: Saltstack
tags: [saltstack, salt, devops]
---

对基础服务的管理包括配置管理系统、用户账号管理、yum配置管理、hosts文件管理、时间同步管理、DNS配置管理。

### 配置管理系统

配置管理系统使用模块化设计，每个服务一个模块，将多个模块组织到一起形成角色（/srv/salt/roles/）。所有模块放置到：/srv/salt下，入口配置文件为：/srv/salt/top.sls。模块使用的变量放置到：/srv/pillar，入口配置文件：/srv/pillar/top.sls。针对变量的作用域不同，将变量分为三级级，一级应用于模块（/srv/pillar/模块名），一级应用于角色（/srv/pillar/roles/），一级应用于主机节点（/srv/pillar/nodes）。具体配置在此不一一列出，具体参见salt配置文件。

入口配置/srv/salt/top.sls，直接引用各种角色：

    base:  
      '*':  
        - roles.common  
      'admin.grid.mall.com':  
        - roles.admin  
      'ha.grid.mall.com':  
        - roles.ha  
      'web*.grid.mall.com':  
        - roles.web  
      'cache*.grid.mall.com':  
        - roles.cache  
      'mc*.grid.mall.com':  
        - roles.mc  
      'db*.grid.mall.com':  
        - roles.db  
      'search*.grid.mall.com':  
        - roles.search  
      'storage*'.grid.mall.com':  
        - roles.storage  

变量入口配置文件/srv/pillar/top.sls：

    base:  
      '*':  
        - roles.common  
      # 引用角色级变量  
      # 模块级变量在角色级变量中引用  
      'admin.grid.mall.com':  
        - roles.admin  
      'ha.grid.mall.com':  
        - roles.ha  
      'web*.grid.mall.com':  
        - roles.web  
      'cache*.grid.mall.com':  
        - roles.cache  
      'mc*.grid.mall.com':  
        - roles.mc  
      'db*.grid.mall.com':  
        - roles.db  
      'search*.grid.mall.com':  
        - roles.search  
      'storage*'.grid.mall.com':  
        - roles.storage  
      # 引用节点级变量
      'ha1.grid.mall.com':  
        - nodes.ha1  
      'ha2.grid.mall.com':
        - nodes.ha2  
      'mc1.grid.mall.com':
        - nodes.mc1  
      'mc2.grid.mall.com':
        - nodes.mc2  
      'db1.grid.mall.com':
        - nodes.db1  
      'db2.grid.mall.com':
        - nodes.db2  

### 用户账号管理

用户管理模块：/srv/salt/users  

此模块用到pillar，pillar和grains都可以用来获取变量，但是grains偏向于获取客户端相关信息，比如客户端硬件架构、cpu核数、操作系统版本等信息，相当于puppet的facter；pillar用于定义用户变量，通过pillar变量的传递，使salt state模块易于重用，相当于puppet的hiera。使用pillar变量之前需要执行salt '*' saltutil.refresh_pillar命令使变量生效。使用命令salt 'admin.grid.mall.com' pillar.item users获取users变量：

    # salt 'admin.grid.mall.com' pillar.item users  
    admin.grid.mall.com:  
        ----------  
        users:  
            ----------  
            dongliang:  
                ----------  
                fullname:  
                    Shi Dongliang  
                gid:  
                    1000  
                group:  
                    dongliang  
                password:  
                    $6$BZpX5dWZ$....... 
                shell:  
                    /bin/bash  
                ssh_auth:  
                    ----------  
                    comment:  
                        dongliang@leju.com  
                    key:  
                        AAAAB3......==  
                sudo:  
                    True  
                uid:  
                    1000  

获取admin.grid.mall.com上面定义的所有pillar变量：

>\# salt 'admin.grid.mall.com' pillar.items

添加用户： 

/srv/salt/users/user.sls用于管理用户

![user1定义](/assets/images/14-05-29/user1.png)
![user2定义](/assets/images/14-05-29/user2.png)

sudo.sls为用户添加sudo权限：

    sudoers:  
      file.managed:  
        - name: /etc/sudoers  

/srv/salt/users/user.sls读取/srv/pillar/users/init.sls中的users变量。

    users:  
      dongliang:  # 定义用户名  
        group: dongliang  # 用户所在组  
        uid: 1000  # 用户uid  
        gid: 1000  # 用户gid  
        fullname: Shi Dongliang  
        password:   $6$BZpX5dWZ$......  # 密码，注意是hash后的密码  
        shell: /bin/bash  # 用户shell  
        sudo: true  # 是否给sudo权限  
        ssh_auth:  # 无密码登录，可选项  
          key: AAAAB3......==  
          comment: dongliang@mall.com 

在salt-master上执行下面命令使配置生效
> \# salt '*' saltutil.refresh_pillar  
> \# salt '*' state.highstate


### yum配置管理

yum配置管理：/srv/salt/base/repo.sls  
配置文件：/srv/salt/base/files/mall.repo  \# 此配置文件可以通过salt协议下发到客户端

/srv/salt/base/repo.sls定义，管理mall.repo文件，当文件改变后执行yum clean all清理缓存，是配置生效。

    /etc/yum.repos.d/mall.repo:  
      file.managed:  
        - source: salt://base/files/mall.repo  
        - user: root  
        - group: root  
        - mode: 644  
        - order: 1  
      cmd.wait:  
        - name: yum clean all  
        - watch:  
           - file: /etc/yum.repos.d/mall.repo  


### hosts文件管理

hosts文件管理：/srv/salt/base/hosts.sls  

/srv/salt/base/hosts.sls 定义了每个主机名和IP的对应关系。如下：

    admin.grid.mall.com:  
      host.present:  
        - ip: 172.16.100.81  
        - order: 1  
        - names:  
          - admin.grid.mall.com  

### 时间同步管理

时间同步作为一个cron，定义文件为：/srv/salt/base/crons.sls

    # 引用ntp模块  
    include:  
      - ntp  

    '/usr/sbin/ntpdate 1.cn.pool.ntp.org 1.asia.pool.ntp.org':  
      cron.present:  
        - user: root  
        - minute: 0  
        - hour: 2  

ntp模块：ntp/init.sls

    # 安装ntpdate软件包  
        ntpdate:  
          pkg.installed:  
            - name: ntpdate  

### DNS配置管理

配置DNS服务器定义在resolv.sls，控制/etc/resolv.conf配置文件:

    /etc/resolv.conf:  
      file.managed:  
        - source: salt://base/files/resolv.conf  
        - user: root  
        - group: root  
        - mode: 644  
        - template: jinja  
